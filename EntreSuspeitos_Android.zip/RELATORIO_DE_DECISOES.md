# Relatório de decisões — Entre Suspeitos v3.0 beta

**Preparado em:** 11 de novembro de 2026  
**Finalidade:** deixar registrado o que foi implementado, as decisões assumidas para não interromper o desenvolvimento e o que ainda depende de configuração, testes ou nova versão.

## 1. Identidade e acessibilidade

| Tema | Decisão adotada | Situação |
|---|---|---|
| Nome do jogo | **Entre Suspeitos** | Implementado |
| Aparência | Tema **Sombra** preto/vermelho como padrão; **Noturno** azul/roxo opcional e salvo no aparelho | Implementado |
| Abertura | Frase aleatória em toda abertura, com grupos comum 70%, incomum 20%, raro 9%, especial 1% | Implementado |
| Frase especial | “O LULA está entre nós.” tem **1% em cada abertura**, sem limite nem ordem previsível | Implementado |
| Frases repetidas | Sorteio independente: a mesma frase pode voltar, inclusive a especial | Decisão assumida para preservar probabilidade exata |
| Sons | Música **original instrumental** de suspense, composta em padrões de notas no código, sem letra nem arquivo de terceiros | Implementado; tocar primeiro em botão pode ser necessário para liberar áudio |
| Música e efeitos | Preferências separadas; música desligada por padrão, efeitos ligados | Implementado |
| Efeitos visuais | Brilho discreto, animação da marca, pulsação nas cartas, transições; reduzidos se o aparelho pedir menos movimento | Implementado |
| Ícones e telas | Mantidos leves para funcionar em Android comum | Implementado |

## 2. Offline — todos num aparelho

| Decisão | Resultado |
|---|---|
| Sem internet e sem cadastro | Mantido |
| Jogadores | Mínimo 4, máximo 30; nomes editáveis e salvos localmente |
| Impostores | De 1 até a maior quantidade **inferior ao número de comuns** |
| Categorias | 12 categorias com 1.322 palavras no banco atual (cada uma com 110 ou 111) |
| Dificuldade | Fácil, Médio, Difícil, Misturado |
| Dicas | Categoria + dica, só categoria, só dica ou nenhuma |
| Conhecer parceiros | Liga/desliga na configuração |
| Carta secreta | **Segurar** para revelar, **soltar** para ocultar; esconder acontece automaticamente |
| Texto no botão | Alterado para **“Próximo jogador →”**; no último, **“Iniciar discussão →”** |
| Ordem de fala | Definida pelas pessoas sentadas, não pelo aplicativo |
| Discussão | Tempo livre, sem voto eletrônico no modo offline |
| Resultado | Revela palavra e identidades; opção de jogar novamente |
| Histórico | Evita repetir palavras selecionadas dentro do banco disponível até esgotá-las; salva no aparelho |

## 3. Online — decisões de infraestrutura

| Tema | Decisão tomada por padrão | Situação |
|---|---|---|
| Banco e autenticação | **Supabase** (PostgreSQL e autenticação por e-mail), com URL e chave pública configuráveis no próprio aplicativo | Código integrado, exige criar e configurar projeto externo |
| Por que Supabase | Permite manter a palavra secreta e a votação em funções no servidor, sem permitir que um cliente comum escolha os próprios pontos | Decisão arquitetural |
| Credenciais | **Nenhuma senha/chave de administrador incluída no APK**; somente a chave pública de conexão poderá ser configurada | Implementado |
| Facebook | Botão informativo; login real exige configurar a Meta e retorno OAuth Android | **Pendente** |
| Tamanho da sala online | **4 a 10 participantes**, limite inicial escolhido por desempenho da voz WebRTC em celulares | Decisão que pode mudar com infraestrutura de voz dedicada |
| Sala pública | Jogador pode criar e esperar participantes; lista e entrada rápida escolhem sala com vaga | Código integrado |
| Sala privada | Código de 6 caracteres; anfitrião pode enviar convites diretamente aos amigos cadastrados | Código integrado |
| Anfitrião | Inicia com no mínimo quatro prontos; pode ajustar impostores e outras regras | Código integrado |
| Alteração de regra | Remove **Pronto** de todos, que devem confirmar novamente | Código integrado no banco |
| Anfitrião ausente | O servidor passa a liderança para um participante conectado após cerca de 20 segundos sem atividade | Decisão automática; necessita teste real |
| Parceiros impostores | Configuração definida antes do início (sabem ou não quem são) | Código integrado |
| Primeira pista | Servidor sorteia quem começa a falar; exibido para todos | Código integrado |
| Discussão | 3 minutos; aviso ao terminar, sem mutar automaticamente os microfones | Código integrado |
| Votação | 30 segundos, voto secreto; cada pessoa escolhe tantos suspeitos quanto impostores configurados; sem repetir, nem votar em si | Código integrado |
| Votos | O voto de quem não votou não é contabilizado; derrota individual para não votante | Código integrado |
| Empate | Nenhum empatado na **última vaga** é identificado; não há segundo turno | Código integrado |
| Vitórias | Impostor descoberto perde individualmente; impostor que escapou vence. Comuns só vencem se todos os impostores ainda participantes forem identificados | Código integrado |
| Reconexão | App guarda última sala e tenta permitir retorno até acabar a votação; partidas seguem para quem permanece | Código integrado; exige teste com desconexões reais |
| Saída durante jogo | Não participar/votar até o fim da votação gera derrota; outros continuam | Código integrado |
| Afastamento por voz | Microfone pode ser ativado/desativado, e o áudio recebido de outro participante pode ser silenciado no próprio aparelho | Código integrado em WebRTC; qualidade depende da rede |
| Sinalização de voz | Feita no banco por troca autenticada de ofertas/respostas/ICE; áudio transmite-se entre aparelhos, não como gravação no banco | Código integrado; **sem servidor TURN próprio**, pode falhar em determinadas operadoras |

## 4. XP, resultados, ranking e social

| Tema | Decisão assumida | Situação |
|---|---|---|
| XP | **Só partidas públicas** concedem XP | Integrado ao backend |
| Privadas | Contam vitórias e derrotas no perfil, mas não XP e ranking | Integrado ao backend |
| Pontos de ranking | Vitória pública: **+25 pontos**. Derrota pública: **−10 pontos**. Pontuação pode ser negativa (temporário) | Decisão provisória, ajustável |
| XP de jogador comum | 20 XP por participação válida, +15 por impostor acertado no próprio voto, +40 se o grupo vencer | Integrado ao backend |
| XP de impostor que escapou | `20 + arredondar(130 × (1 − votos_recebidos / outros_votantes))`, até 150 XP | Integrado ao backend |
| XP de impostor descoberto | `20 + arredondar(30 × (1 − votos_recebidos / outros_votantes))`; +10% se um parceiro escapou | Integrado ao backend |
| Abandono/não votar | Derrota individual e 0 XP na rodada | Integrado ao backend |
| Amigos | Busca por apelido, pedidos, aceitação, convites diretos no lobby | Código integrado |
| Fotos | Placeholder por inicial do apelido; upload seguro de fotos ainda não foi implementado | Pendente |
| Títulos / raridades | Comum marrom, incomum azul, raro verde, Lenda dourado, Místico vermelho/laranja | **Regras documentadas; desbloqueio ainda pendente** |
| Místicos | Títulos únicos desconhecidos até o primeiro desbloqueio, sem revelar o método | **Não inventei condições nem ativei títulos artificiais**; implementação futura protegida no servidor |
| Conquista Top 10 | Planejada para quem escapa como impostor sem votos de adversários do Top 10; versão correspondente para comuns | Pendente |
| Ranking de lançamento | Ainda é beta: não há proteção suficiente contra contas combinando resultados para farmar pontos | Necessita antifraude antes de publicação |

## 5. Admin, suporte e privacidade

| Tema | Decisão | Situação |
|---|---|---|
| Acesso administrativo | Nenhum administrador pré-cadastrado. **Você** autoriza sua conta por SQL no serviço após criar o cadastro | Protege o APK de conter acesso secreto |
| Painel | Quantidade de contas, jogadores ativos, salas, partidas, solicitações e denúncias | Código integrado |
| Conteúdo | Botão de envio das 1.322 palavras para o banco online em blocos de 100, sem listar palavras na tela | Código integrado |
| Sugestões e denúncias | Formulário, denúncia de jogador da sala, status de análise e resolução | Código integrado |
| Punição | Administrador pode suspender conta denunciada por 7 dias após análise; há função de remover suspensão no banco | Código integrado; revisão humana necessária |
| Privacidade | Sessão de usuário guardada localmente; nenhuma credencial de serviço privilegiado no APK | Decisão técnica; política e consentimentos ainda precisam ser preparados |
| Antiabuso | Não há análise automática de fala nem gravação de áudio por padrão | Decisão que preserva privacidade |
| Moderação | Apenas a conta principal do administrador. Sem papéis de moderadores adicionais nesta versão | Decisão provisória |

## 6. O que NÃO posso afirmar como concluído

1. **O APK V3 ainda não foi compilado no seu GitHub nem instalado no seu aparelho.** Os testes foram de navegador com simulação de toque, sorteio e navegação offline; parte da interface online foi simulada com respostas falsas para verificar os botões.
2. **Não foi criado nem configurado um projeto real Supabase** para o usuário. Até isso acontecer, a experiência online não conecta jogadores.
3. **O chat de voz ainda não foi validado em Android**. Permissões nativas, restrições da operadora e eventual TURN podem exigir correção. Ele usa microfone somente após pedido de permissão.
4. **Facebook OAuth, fotos de perfil, conquistas, molduras e títulos secretos únicos ainda não estão prontos.** As telas de conta básica, amigos e ranking beta foram criadas, mas a parte avançada permanece pendente.
5. **A segurança da API e as regras SQL precisam de teste com dois usuários reais antes de divulgação pública**. Bancos públicos e ranking exigem monitoramento, controle de abusos, antifraude e documentação de privacidade.
6. **A assinatura do APK de testes não é persistente** entre builds GitHub; talvez seja necessário desinstalar versões anteriores antes de instalar a nova, perdendo dados locais.

## 7. Melhor ordem para continuar

1. Substituir ZIP, atualizar workflow, compilar APK V3 e testar **offline**.
2. Criar projeto Supabase, instalar SQL e configurar a conta de administrador e o banco de palavras.
3. Testar sala privada com dois aparelhos, depois com **quatro jogadores reais**, incluindo votos, cronômetro, reconexão e som.
4. Corrigir microfone/permissões e, se necessário, implementar TURN/serviço de áudio com menor consumo para grupos grandes.
5. Criar proteção antifraude do ranking e revisar moderação, privacidade e LGPD.
6. Adicionar títulos comuns/incomuns/raros, Lendas pioneiras e Místicos sem expor as condições no painel; implementar fotos e Facebook OAuth.
7. Só depois considerar publicação oficial em lojas de aplicativos.

**As decisões adotadas são revisáveis.** Basta solicitar a alteração de qualquer linha deste relatório na próxima atualização.
