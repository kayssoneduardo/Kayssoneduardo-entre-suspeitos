# Ativar o online pelo Android — passos reduzidos

1. Crie conta e um projeto novo em `https://supabase.com/dashboard`.
2. Abra o projeto → **SQL Editor → New query**. Copie o arquivo `backend/01_instalar.sql` do projeto e execute. Deve terminar sem mensagens de erro. **Caso dê erro, não prossiga: envie uma captura do erro**.
3. Ative **Authentication → Providers → Email** e configure confirmação por e-mail.
4. Copie a URL pública e a chave **anon/publishable** em **Project Settings → API**.
5. Entre no seu repositório GitHub → **Settings → Secrets and variables → Actions → Variables → New repository variable**. Crie `SUPABASE_URL` com a URL e `SUPABASE_ANON_KEY` com a chave **pública**.
6. No GitHub Actions, execute **Gerar APK Android**, baixe o novo APK e instale.
7. Crie uma conta por e-mail dentro do app. No Supabase, execute `select id,email from auth.users;` e encontre o UUID da sua conta. Rode `insert into public.es_admins(user_id) values ('SEU-UUID') on conflict do nothing;`.
8. Abra **Jogar Online → Painel administrativo → Publicar palavras**. Teste com 4 contas diferentes (se possível, dois Androids).

**NUNCA copie `service_role` para o aplicativo, para o GitHub ou para o chat.** Para o online funcionar entre pessoas diferentes, esta configuração realmente precisa estar ativa. Facebook, voz em todas as redes e publicação pública ainda dependem de testes adicionais.
