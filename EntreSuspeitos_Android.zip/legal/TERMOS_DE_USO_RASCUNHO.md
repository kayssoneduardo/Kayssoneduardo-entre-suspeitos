# Termos de uso — RASCUNHO, NÃO PUBLICAR SEM REVISÃO

O Entre Suspeitos é um jogo social de blefe e adivinhação. O modo online depende de conta e conexão com internet, e pode estar indisponível durante testes. Não é permitido usar o serviço para ameaça, assédio, divulgação de dados de terceiros, fraude de ranking ou qualquer violação da legislação aplicável. Os participantes podem denunciar comportamentos inadequados. Advertências e suspensões devem ser analisadas conforme critérios objetivos, com possibilidade de revisão.

A comunicação por voz não é gravada por padrão na implementação atual; entretanto outros participantes podem fazer gravações externas, fora do controle do aplicativo. Os nomes, imagens e conteúdos compartilhados devem respeitar direitos de terceiros. Estatísticas e conquistas podem ser ajustadas para corrigir erros e abuso. É necessário estabelecer idade mínima e regras claras para menores antes de liberar salas públicas.

**Preencher o responsável, contato, regras finais, privacidade e processo de recurso antes de publicar.**
