# Política de privacidade — RASCUNHO, NÃO PUBLICAR SEM REVISÃO

Aplicativo: Entre Suspeitos. Responsável pelo tratamento: **[preencher identificação e canal de contato antes de publicar]**.

Se o usuário usar somente o modo offline, as configurações e nomes escolhidos são mantidos no próprio aparelho e não precisam ser enviados a servidor. No modo online, poderão ser tratados dados da conta (e-mail, apelido), foto de perfil opcional, amizades, salas, votos, estatísticas, denúncias e registros técnicos necessários ao serviço. As conversas por voz usam conexões entre dispositivos em tempo real; a implementação atual não prevê gravar o áudio no servidor. Provedores de autenticação e hospedagem poderão processar informações técnicas de conexão.

Finalidades previstas: autenticação, prestação do jogo, contagem de pontos, combate a fraudes, moderação, suporte e segurança. Fotos e apelidos poderão ser visíveis a outros jogadores. É preciso definir bases legais, retenção, transferências internacionais, diretrizes para menores, exclusão e exercício de direitos no contexto da LGPD antes do lançamento.

**Este documento não é suficiente para publicação**, pois depende dos dados reais do controlador, infraestrutura contratada, formas de contato, retenção, procedimentos de exclusão/portabilidade e revisão jurídica.
