import json, pathlib, unicodedata, re, collections
# Each thematic cluster has an intentional hint: useful for the impostor, without naming the answer.
# Cluster difficulty distribution: easy (first 4), medium (next 3), hard (last 3).
GROUPS = {
'Animais': [
 ('vida doméstica','Cachorro,Gato,Cavalo,Vaca,Porco,Ovelha,Cabra,Coelho,Galinha,Pato,Peru'),
 ('campo e fazenda','Burro,Boi,Búfalo,Ganso,Marreco,Codorna,Pombo,Canário,Pavão,Periquito,Hamster'),
 ('selvagem','Leão,Tigre,Elefante,Girafa,Zebra,Rinoceronte,Hipopótamo,Macaco,Gorila,Urso,Lobo'),
 ('água','Tubarão,Golfinho,Baleia,Polvo,Lula,Peixe-palhaço,Estrela-do-mar,Cavalo-marinho,Caranguejo,Água-viva,Tartaruga-marinha'),
 ('floresta','Onça-pintada,Capivara,Preguiça,Tamanduá,Tatu,Anta,Quati,Mico-leão-dourado,Arara,Tucano,Jaguatirica'),
 ('asas e voo','Águia,Falcão,Coruja,Gavião,Beija-flor,Andorinha,Pica-pau,Flamingo,Pelicano,Cisne,Avestruz'),
 ('natureza pequena','Formiga,Abelha,Borboleta,Libélula,Grilo,Gafanhoto,Joaninha,Besouro,Mosquito,Aranha,Escorpião'),
 ('habitat gelado','Pinguim,Foca,Morsa,Orca,Narval,Urso-polar,Lebre-ártica,Raposa-do-ártico,Boi-almiscarado,Albatroz,Papagaio-do-mar'),
 ('vida selvagem','Suricato,Hiena,Chacal,Guepardo,Okapi,Lêmure,Caracal,Fossa,Ai-ai,Pangolim,Saiga'),
 ('rios e pântanos','Axolote,Salamandra,Tritão,Peixe-boi,Ariranha,Lontra,Sucuri,Jacaré,Crocodilo,Gavial,Enguia-elétrica'),
],
'Comidas': [
 ('mesa brasileira','Arroz,Feijão,Macarrão,Lasanha,Pizza,Hambúrguer,Cachorro-quente,Pastel,Coxinha,Esfiha,Empada'),
 ('sobremesa','Brigadeiro,Beijinho,Pudim,Bolo,Sorvete,Chocolate,Gelatina,Paçoca,Quindim,Mousse,Doce de leite'),
 ('café da manhã','Pão francês,Tapioca,Cuscuz,Pão de queijo,Omelete,Panqueca,Torrada,Cereal,Iogurte,Biscoito,Bolo de milho'),
 ('comida caseira','Feijoada,Churrasco,Strogonoff,Purê de batata,Sopa,Farofa,Salpicão,Arroz carreteiro,Galinhada,Canja,Moqueca'),
 ('cozinha oriental','Sushi,Sashimi,Temaki,Yakissoba,Ramen,Gyoza,Missoshiru,Onigiri,Udon,Tempurá,Kimchi'),
 ('pratos regionais','Acarajé,Vatapá,Baião de dois,Carne de sol,Arroz de cuxá,Tacacá,Maniçoba,Pato no tucupi,Caldeirada,Escondidinho,Pamonha'),
 ('sabor internacional','Risoto,Nhoque,Fondue,Paella,Burrito,Taco,Quesadilla,Guacamole,Falafel,Hommus,Kebab'),
 ('doçaria artesanal','Macaron,Éclair,Mil-folhas,Tiramisu,Cheesecake,Brownie,Petit gâteau,Pavlova,Crème brûlée,Strudel,Banoffee'),
 ('cozinha do mundo','Ceviche,Poke,Bibimbap,Curry,Pad thai,Moussaka,Shakshuka,Pierogi,Goulash,Ratatouille,Borscht'),
 ('sabores tradicionais','Sagu,Ambrosia,Canjica,Curau,Arroz doce,Cocada,Queijadinha,Cartola,Chipa,Chimarrão,Chutney'),
],
'Objetos': [
 ('uso diário','Celular,Chave,Carteira,Relógio,Óculos,Espelho,Escova,Pente,Mochila,Guarda-chuva,Caneta'),
 ('casa','Cadeira,Mesa,Sofá,Cama,Travesseiro,Cobertor,Tapete,Cortina,Abajur,Vaso,Armário'),
 ('cozinha','Panela,Frigideira,Colher,Garfo,Faca,Prato,Copo,Xícara,Chaleira,Escorredor,Peneira'),
 ('estudos','Caderno,Lápis,Borracha,Régua,Apontador,Tesoura,Cola,Grampeador,Calculadora,Marca-texto,Estojo'),
 ('eletrônicos','Controle remoto,Fone de ouvido,Teclado,Mouse,Monitor,Carregador,Microfone,Câmera,Impressora,Roteador,Projetor'),
 ('ferramentas','Martelo,Alicate,Chave de fenda,Furadeira,Serrote,Trena,Parafuso,Prego,Chave inglesa,Nível,Esquadro'),
 ('viagem e lazer','Mala,Bússola,Binóculo,Lanterna,Barraca,Churrasqueira,Prancha,Patins,Raquete,Cantil,Mapa'),
 ('antiguidades','Gramofone,Máquina de escrever,Ampulheta,Pergaminho,Bússola náutica,Monóculo,Luneta,Castiçal,Vitrô,Vitrola,Tinteiro'),
 ('equipamento técnico','Osciloscópio,Multímetro,Paquímetro,Microscópio,Telescópio,Barômetro,Anemômetro,Sismógrafo,Termômetro infravermelho,Higrômetro,Teodolito'),
 ('arte e artesanato','Cavalete,Pincel,Paleta,Godê,Bastidor,Agulha de crochê,Formão,Torno de oleiro,Espátula de pintura,Carimbo,Soprador térmico'),
],
'Lugares': [
 ('pontos da cidade','Escola,Hospital,Supermercado,Padaria,Farmácia,Biblioteca,Cinema,Restaurante,Posto de gasolina,Banco,Correios'),
 ('passeio e lazer','Praia,Parque,Shopping,Estádio,Teatro,Museu,Zoológico,Aquário,Praça,Feira,Clube'),
 ('construções','Castelo,Igreja,Prédio,Ponte,Túnel,Torre,Palácio,Fortaleza,Farol,Estação de trem,Aeroporto'),
 ('natureza','Floresta,Deserto,Cachoeira,Rio,Lago,Montanha,Vale,Caverna,Ilha,Campo,Pântano'),
 ('viagem','Rodoviária,Hotel,Pousada,Camping,Porto,Marina,Terminal de ônibus,Mirante,Jardim botânico,Parque aquático,Resort'),
 ('vida pública','Prefeitura,Fórum,Delegacia,Quartel,Embaixada,Consulado,Universidade,Observatório,Planetário,Arquivo público,Assembleia legislativa'),
 ('geografia mundial','Amazônia,Sertão,Savana,Tundra,Estepe,Taiga,Delta,Fiorde,Oásis,Geleira,Atol'),
 ('lugares históricos','Coliseu,Taj Mahal,Stonehenge,Machu Picchu,Petra,Partenon,Angkor Wat,Chichén Itzá,Pompeia,Alhambra,Muralha da China'),
 ('natureza extrema','Grand Canyon,Monte Everest,Mar Morto,Deserto do Atacama,Deserto do Saara,Fossa das Marianas,Monte Kilimanjaro,Lago Baikal,Salinas Grandes,Ilhas Galápagos,Cataratas do Iguaçu'),
 ('paisagens distantes','Salar de Uyuni,Monte Fuji,Monte Roraima,Uluru,Capadócia,Monte Olimpo,Lago Titicaca,Ilha de Páscoa,Mar de Aral,Lago Vitória,Monte Vesúvio'),
],
'Profissões': [
 ('trabalho cotidiano','Professor,Médico,Enfermeiro,Advogado,Motorista,Cozinheiro,Vendedor,Pedreiro,Mecânico,Policial,Bombeiro'),
 ('serviços','Eletricista,Encanador,Carpinteiro,Pintor,Cabeleireiro,Barbeiro,Costureira,Garçom,Recepcionista,Entregador,Jardineiro'),
 ('escritório e empresa','Contador,Administrador,Secretário,Gerente,Empresário,Economista,Analista de dados,Programador,Designer,Publicitário,Corretor de imóveis'),
 ('saúde e cuidado','Dentista,Veterinário,Fisioterapeuta,Psicólogo,Nutricionista,Farmacêutico,Fonoaudiólogo,Terapeuta ocupacional,Biólogo,Técnico de enfermagem,Agente comunitário de saúde'),
 ('arte e comunicação','Jornalista,Fotógrafo,Ator,Cantor,Músico,Escritor,Roteirista,Diretor de cinema,Editor de vídeo,Locutor,Ilustrador'),
 ('ciência e tecnologia','Engenheiro,Arquiteto,Químico,Físico,Astrônomo,Geólogo,Cartógrafo,Oceanógrafo,Pesquisador,Roboticista,Desenvolvedor de jogos'),
 ('campo e transporte','Agricultor,Agrônomo,Pescador,Apicultor,Tratorista,Comissário de bordo,Piloto de avião,Maquinista,Caminhoneiro,Marinheiro,Guia turístico'),
 ('profissões especializadas','Perito criminal,Neurocirurgião,Anestesista,Arqueólogo,Restaurador de obras,Tradutor juramentado,Sommelier,Mergulhador profissional,Controlador de voo,Operador de guindaste,Auditor'),
 ('trabalho singular','Relojoeiro,Luthier,Taxidermista,Ourives,Entomologista,Ornitólogo,Numismata,Calígrafo,Acústico,Geofísico,Criptógrafo'),
 ('profissões históricas','Ferreiro,Alfaiate,Sapateiro,Oleiro,Tipógrafo,Escriba,Cartógrafo naval,Mensageiro,Alquimista,Funileiro,Carrasco'),
],
'Animes': [
 ('aventura e amizade','Naruto,One Piece,Dragon Ball,Pokémon,Digimon,Bleach,Fairy Tail,Black Clover,Hunter x Hunter,My Hero Academia,Demon Slayer'),
 ('histórias famosas','Death Note,Attack on Titan,Fullmetal Alchemist,One Punch Man,Jujutsu Kaisen,Chainsaw Man,Spy x Family,Tokyo Ghoul,Sword Art Online,Dr. Stone,Haikyuu!!'),
 ('clássicos da televisão','Cavaleiros do Zodíaco,Sailor Moon,Inuyasha,Yu Yu Hakusho,Samurai X,Shaman King,Beyblade,Bakugan,Medabots,Super Campeões,Hamtaro'),
 ('animação e emoção','A Viagem de Chihiro,Meu Amigo Totoro,O Castelo Animado,Ponyo,Princesa Mononoke,Your Name,Weathering with You,A Voz do Silêncio,O Túmulo dos Vagalumes,Akira,O Serviço de Entregas da Kiki'),
 ('competição','Blue Lock,Kuroko no Basket,Free!,Yuri on Ice,Hajime no Ippo,Ace of Diamond,Sk8 the Infinity,Slam Dunk,Initial D,Yowamushi Pedal,Run with the Wind'),
 ('romance e cotidiano','Toradora!,Horimiya,Fruits Basket,Clannad,Your Lie in April,Kaguya-sama: Love Is War,Komi Can’t Communicate,Nana,Golden Time,My Dress-Up Darling,Violet Evergarden'),
 ('fantasia e outros mundos','Re:Zero,Overlord,No Game No Life,Konosuba,That Time I Got Reincarnated as a Slime,The Rising of the Shield Hero,Made in Abyss,Mushoku Tensei,Log Horizon,Grimgar,The Eminence in Shadow'),
 ('mistério e tensão','Monster,Erased,Parasyte,Steins;Gate,Psycho-Pass,Serial Experiments Lain,Another,Death Parade,The Promised Neverland,Odd Taxi,Paranoia Agent'),
 ('universos peculiares','Cowboy Bebop,Neon Genesis Evangelion,Code Geass,Gurren Lagann,Trigun,Samurai Champloo,Dorohedoro,Baccano!,Durarara!!,FLCL,Space Dandy'),
 ('anime cult','Mushishi,Texhnolyze,Haibane Renmei,Kaiba,Ping Pong the Animation,Mononoke,The Tatami Galaxy,Sonny Boy,Kino’s Journey,Planetes,The Eccentric Family'),
],
'Personagens de animes': [
 ('ninja e vila','Naruto Uzumaki,Sasuke Uchiha,Sakura Haruno,Kakashi Hatake,Itachi Uchiha,Gaara,Jiraiya,Tsunade,Orochimaru,Minato Namikaze,Hinata Hyuga'),
 ('piratas e mares','Monkey D. Luffy,Roronoa Zoro,Nami,Sanji,Usopp,Tony Tony Chopper,Nico Robin,Franky,Brook,Portgas D. Ace,Shanks'),
 ('energia e torneios','Son Goku,Vegeta,Gohan,Piccolo,Trunks,Freeza,Cell,Majin Boo,Bulma,Krillin,Androide 18'),
 ('caçadores e monstros','Tanjiro Kamado,Nezuko Kamado,Zenitsu Agatsuma,Inosuke Hashibira,Giyu Tomioka,Shinobu Kocho,Kyojuro Rengoku,Muzan Kibutsuji,Tengen Uzui,Muichiro Tokito,Mitsuri Kanroji'),
 ('titãs e muralhas','Eren Yeager,Mikasa Ackerman,Armin Arlert,Levi Ackerman,Erwin Smith,Hange Zoë,Jean Kirstein,Reiner Braun,Annie Leonhart,Sasha Braus,Zeke Yeager'),
 ('maldições e exorcismo','Yuji Itadori,Satoru Gojo,Megumi Fushiguro,Nobara Kugisaki,Ryomen Sukuna,Kento Nanami,Maki Zenin,Yuta Okkotsu,Toge Inumaki,Toji Fushiguro,Mahito'),
 ('detetives e cadernos','Light Yagami,L Lawliet,Ryuk,Misa Amane,Near,Mello,Soichiro Yagami,Teru Mikami,Naomi Misora,Rem,Watari'),
 ('alquimia e metal','Edward Elric,Alphonse Elric,Winry Rockbell,Roy Mustang,Riza Hawkeye,Maes Hughes,Scar,Alex Louis Armstrong,Van Hohenheim,King Bradley,Izumi Curtis'),
 ('heróis e poderes','Izuku Midoriya,Katsuki Bakugo,Shoto Todoroki,All Might,Ochaco Uraraka,Tenya Iida,Endeavor,Tomura Shigaraki,Himiko Toga,Eijiro Kirishima,Tsuyu Asui'),
 ('caçada e aura','Gon Freecss,Killua Zoldyck,Kurapika,Leorio Paradinight,Hisoka Morow,Chrollo Lucilfer,Meruem,Neferpitou,Isaac Netero,Biscuit Krueger,Illumi Zoldyck'),
],
'Filmes': [
 ('sucessos de bilheteria','Titanic,Avatar,Vingadores: Ultimato,Jurassic Park,O Rei Leão,Harry Potter e a Pedra Filosofal,Homem-Aranha: Sem Volta para Casa,Barbie,Super Mario Bros. O Filme,Divertida Mente 2,Pantera Negra'),
 ('animação e família','Toy Story,Shrek,Procurando Nemo,Os Incríveis,Frozen,Up: Altas Aventuras,Monstros S.A.,Ratatouille,Kung Fu Panda,Meu Malvado Favorito,Encanto'),
 ('aventura e fantasia','O Senhor dos Anéis: A Sociedade do Anel,Piratas do Caribe: A Maldição do Pérola Negra,Indiana Jones e os Caçadores da Arca Perdida,As Crônicas de Nárnia,Jumanji,A Fantástica Fábrica de Chocolate,Aladdin,A Bela e a Fera,O Mágico de Oz,Alice no País das Maravilhas,Malévola'),
 ('ação e heróis','Batman: O Cavaleiro das Trevas,Homem de Ferro,Capitão América: O Primeiro Vingador,Guardiões da Galáxia,Doutor Estranho,Thor: Ragnarok,Missão Impossível,007: Cassino Royale,Velozes e Furiosos,John Wick,Top Gun: Maverick'),
 ('ficção e futuro','Matrix,Interestelar,A Origem,Blade Runner 2049,Duna,Star Wars: Uma Nova Esperança,De Volta para o Futuro,Ex Machina,Gravidade,Perdido em Marte,2001: Uma Odisseia no Espaço'),
 ('terror e suspense','O Exorcista,O Iluminado,Invocação do Mal,It: A Coisa,Corra!,Um Lugar Silencioso,Pânico,Atividade Paranormal,A Bruxa,Hereditário,Fragmentado'),
 ('drama e emoção','Forrest Gump,À Espera de um Milagre,Um Sonho de Liberdade,A Vida é Bela,Clube da Luta,A Lista de Schindler,Extraordinário,À Procura da Felicidade,O Pianista,Sociedade dos Poetas Mortos,Milagre na Cela 7'),
 ('cinema cult','O Poderoso Chefão,Pulp Fiction: Tempo de Violência,Taxi Driver,Cidadão Kane,Psicose,Laranja Mecânica,Apocalypse Now,O Grande Lebowski,Casablanca,Janela Indiscreta,O Sétimo Selo'),
 ('cinema brasileiro','Cidade de Deus,Tropa de Elite,Central do Brasil,Auto da Compadecida,Que Horas Ela Volta?,O Homem que Copiava,Lisbela e o Prisioneiro,Bacurau,Ainda Estou Aqui,Carandiru,Marte Um'),
 ('premiados e autorais','Parasita,Whiplash: Em Busca da Perfeição,La La Land,Oppenheimer,Pobres Criaturas,Tudo em Todo Lugar ao Mesmo Tempo,Nomadland,Amor,Amnésia,Mulholland Drive,Aftersun,A Forma da Água'),
],
'Personagens de filmes': [
 ('super-heróis','Homem-Aranha,Homem de Ferro,Capitão América,Thor,Hulk,Viúva Negra,Pantera Negra,Doutor Estranho,Batman,Superman,Mulher-Maravilha'),
 ('animação e fantasia','Shrek,Burro,Fiona,Woody,Buzz Lightyear,Elsa,Anna,Simba,Timão,Pumba,Remy'),
 ('sagas famosas','Harry Potter,Hermione Granger,Rony Weasley,Alvo Dumbledore,Lorde Voldemort,Darth Vader,Luke Skywalker,Princesa Leia,Han Solo,Yoda,Obi-Wan Kenobi'),
 ('aventura e cinema','Jack Sparrow,Indiana Jones,Forrest Gump,Rose DeWitt Bukater,Jack Dawson,Marty McFly,Doc Brown,Katniss Everdeen,Peeta Mellark,Willy Wonka,Aladdin'),
 ('vilões e anti-heróis','Coringa,Arlequina,Loki,Thanos,Duende Verde,Magneto,Hannibal Lecter,Freddy Krueger,Jason Voorhees,Chucky,Michael Myers'),
 ('histórias mágicas','Frodo Bolseiro,Gandalf,Aragorn,Legolas,Gollum,Bilbo Bolseiro,Aslan,Edmund Pevensie,Lucy Pevensie,Malévola,Bela'),
 ('cinema e espionagem','James Bond,Ethan Hunt,Jason Bourne,John Wick,Neo,Trinity,Morpheus,Sarah Connor,T-800,Ellen Ripley,Rick Deckard'),
 ('personagens marcantes','Rocky Balboa,Rambo,Don Vito Corleone,Michael Corleone,Tyler Durden,Andy Dufresne,Red Redding,Miranda Priestly,Regina George,Mia Wallace,Vincent Vega'),
 ('cinema contemporâneo','Barbie,Ken,J. Robert Oppenheimer,Paul Atreides,Chani,Maximus Decimus Meridius,Imperator Furiosa,Max Rockatansky,Benoit Blanc,Arthur Fleck,Amélie Poulain'),
 ('ficção e criaturas','Davy Jones,Groot,Rocket Raccoon,Chewbacca,R2-D2,C-3PO,Optimus Prime,Bumblebee,Godzilla,King Kong,Beetlejuice'),
],
'Personagens históricos': [
 ('história do Brasil','Dom Pedro I,Dom Pedro II,Princesa Isabel,Tiradentes,Zumbi dos Palmares,Marechal Deodoro da Fonseca,Getúlio Vargas,Juscelino Kubitschek,Santos Dumont,Anita Garibaldi,Duque de Caxias'),
 ('ciência e invenções','Albert Einstein,Isaac Newton,Marie Curie,Charles Darwin,Galileu Galilei,Nikola Tesla,Thomas Edison,Ada Lovelace,Alan Turing,Louis Pasteur,Stephen Hawking'),
 ('história do mundo','Cleópatra,Júlio César,Alexandre, o Grande,Napoleão Bonaparte,Joana d’Arc,Cristóvão Colombo,Leonardo da Vinci,Mahatma Gandhi,Nelson Mandela,Abraham Lincoln,Winston Churchill'),
 ('arte e cultura','William Shakespeare,Michelangelo,Vincent van Gogh,Pablo Picasso,Frida Kahlo,Ludwig van Beethoven,Wolfgang Amadeus Mozart,Johann Sebastian Bach,Charlie Chaplin,Chiquinha Gonzaga,Carmen Miranda'),
 ('pensamento e ideias','Sócrates,Platão,Aristóteles,René Descartes,Immanuel Kant,Karl Marx,Simone de Beauvoir,Hannah Arendt,John Locke,Montesquieu,Voltaire'),
 ('mulheres históricas','Hipátia,Ana Néri,Florence Nightingale,Rosa Parks,Amelia Earhart,Malala Yousafzai,Indira Gandhi,Golda Meir,Elizabeth I,Harriet Tubman,Nísia Floresta'),
 ('explorações e viagens','Marco Polo,Vasco da Gama,Fernão de Magalhães,Pedro Álvares Cabral,James Cook,Roald Amundsen,Robert Falcon Scott,Yuri Gagarin,Neil Armstrong,Valentina Tereshkova,Jacques Cousteau'),
 ('antiguidade e impérios','Hamurábi,Ciro, o Grande,Dario I,Xerxes I,Aníbal Barca,Augusto,Nero,Constantino, o Grande,Atila,Justiniano I,Gengis Khan,Saladino'),
 ('revoluções e política','Robespierre,Georges Danton,Simón Bolívar,José de San Martín,George Washington,Thomas Jefferson,Lenin,Leon Trotsky,Mikhail Gorbachev,Margaret Thatcher,Susan B. Anthony'),
 ('pesquisa e conhecimento','Johannes Kepler,Nicolau Copérnico,Blaise Pascal,Antoine Lavoisier,Dmitri Mendeleev,Gregor Mendel,Michael Faraday,Rosalind Franklin,Katherine Johnson,Enrico Fermi,Euclides'),
],
'Marcas': [
 ('tecnologia','Apple,Samsung,Microsoft,Google,Sony,LG,Motorola,Xiaomi,Nokia,Dell,Lenovo'),
 ('roupa e calçado','Nike,Adidas,Puma,Reebok,Vans,Converse,Lacoste,Zara,Renner,C&A,Hering'),
 ('alimentação','Coca-Cola,Pepsi,Nestlé,McDonald’s,Burger King,Subway,KFC,Starbucks,Heinz,Danone,Habib’s'),
 ('carros e motos','Ferrari,Lamborghini,Ford,Chevrolet,Volkswagen,Fiat,Toyota,Honda,BMW,Mercedes-Benz,Hyundai'),
 ('entretenimento','Netflix,Disney,Warner Bros.,Nintendo,PlayStation,Xbox,Spotify,TikTok,YouTube,Paramount,Universal Pictures'),
 ('esportes e lifestyle','New Balance,Asics,Under Armour,Fila,Olympikus,Oakley,The North Face,Columbia,Timberland,Decathlon,Skechers'),
 ('eletrodomésticos','Brastemp,Electrolux,Consul,Philips,Panasonic,Arno,Tramontina,Mondial,Oster,Britânia,Philco'),
 ('cosméticos e beleza','Natura,O Boticário,Avon,L’Oréal,Maybelline,Nivea,Dove,Pantene,Garnier,Sephora,MAC Cosmetics'),
 ('luxo e moda','Gucci,Prada,Chanel,Louis Vuitton,Hermès,Rolex,Cartier,Dior,Versace,Balenciaga,Burberry'),
 ('indústria e serviços','Bosch,3M,Siemens,Intel,AMD,Nvidia,Canon,Nikon,GoPro,John Deere,Caterpillar'),
],
'Esportes': [
 ('esportes populares','Futebol,Basquete,Vôlei,Tênis,Natação,Atletismo,Ciclismo,Boxe,Judô,Surfe,Handebol'),
 ('práticas esportivas','Futsal,Vôlei de praia,Tênis de mesa,Badminton,Skate,Ginástica artística,Capoeira,Karatê,Taekwondo,Esgrima,Triatlo'),
 ('jogos com bola','Rugby,Beisebol,Softbol,Críquete,Futebol americano,Hóquei sobre grama,Polo aquático,Golfe,Boliche,Squash,Peteca'),
 ('força e resistência','Levantamento de peso,Maratona,Corrida de obstáculos,Cross-country,Remo,Canoagem,Escalada esportiva,Mountain bike,Duathlon,Marcha atlética,Arremesso de peso'),
 ('esportes de inverno','Esqui alpino,Esqui cross-country,Salto de esqui,Patinação artística,Patinação de velocidade,Hóquei no gelo,Curling,Bobsled,Luge,Skeleton,Snowboard'),
 ('combate e precisão','Jiu-jítsu,Luta olímpica,Muay thai,Kickboxing,Kendo,Aikido,Sumô,Tiro com arco,Tiro esportivo,Paintball,Airsoft'),
 ('água e aventura','Mergulho livre,Mergulho em apneia,Stand up paddle,Vela,Kitesurf,Windsurf,Rafting,Wakeboard,Esqui aquático,Bodyboard,Pesca esportiva'),
 ('esportes de pista','Automobilismo,Motocross,Kart,Enduro,Motovelocidade,Drift,BMX Racing,BMX Freestyle,Ciclismo de pista,Patinação inline,Patinação de velocidade em pista curta'),
 ('esportes de origem diversa','Kabaddi,Sepak takraw,Lacrosse,Floorball,Ultimate frisbee,Corfebol,Bocha,Peteca de rede,Tchoukball,Pickleball,Padel'),
 ('modalidades incomuns','Pentatlo moderno,Decatlo,Heptatlo,Orientação esportiva,Escalada no gelo,Slalom de canoagem,Polo equestre,Volteio equestre,Adestramento equestre,Salto equestre,Biatlo'),
],
}

# Split entries on commas while preserving deliberate commas within names.
REPLACEMENTS = {'Alexandre, o Grande':'Alexandre o Grande','Ciro, o Grande':'Ciro o Grande','Constantino, o Grande':'Constantino o Grande'}

def norm(s):
    return ''.join(ch for ch in unicodedata.normalize('NFD',s.casefold()) if unicodedata.category(ch)!='Mn').strip()

records={}
for category,groups in GROUPS.items():
    entries=[]; seen=set()
    for group_index,(hint,string) in enumerate(groups):
        for old,new in REPLACEMENTS.items(): string=string.replace(old,new)
        words=[s.strip() for s in string.split(',') if s.strip()]
        difficulty=['Fácil','Médio','Difícil'][min(2,group_index//4 if group_index<4 else (1 if group_index<7 else 2))]
        assert len(words)>=9, (category,group_index,len(words))
        for word in words:
            key=norm(word)
            if key in seen: raise ValueError(f'duplicated within category {category}: {word}')
            seen.add(key)
            # A thematic association, intentionally not a direct synonym, to avoid giving away the word.
            entries.append({'w':word,'h':hint,'d':difficulty})
    assert len(entries)>=100,(category,len(entries))
    records[category]=entries

root=pathlib.Path(__file__).parent
(root/'www'/'words.js').write_text('window.ES_WORD_BANK = '+json.dumps(records,ensure_ascii=False,separators=(',',':'))+';\n', encoding='utf-8')
(root/'words-counts.json').write_text(json.dumps({k:{'total':len(v),**dict(collections.Counter(x['d'] for x in v))} for k,v in records.items()}, ensure_ascii=False,indent=2),encoding='utf-8')
print('Total',sum(len(v) for v in records.values()))
for k,vs in records.items(): print(k,len(vs),collections.Counter(x['d'] for x in vs))
