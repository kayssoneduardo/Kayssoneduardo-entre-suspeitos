# Entre Suspeitos — Versão 2.0 (offline)

Atualização do aplicativo Android para partidas presenciais usando um único celular.

## Principais melhorias

- Abertura cinematográfica com frases sorteadas: comuns 70%, incomuns 20%, raras 9%, frase especial 1%.
- Menu principal com acesso a Offline, Online (em desenvolvimento), perfil, ranking, amigos e configurações.
- Temas Sombra (preto/vermelho) e Noturno (azul/roxo).
- Música ambiente original e efeitos sonoros sintetizados no aparelho, todos opcionais.
- Revelação do papel ao manter a carta pressionada; ao soltar, o papel é ocultado.
- Tela de resultado: palavra secreta e impostores; jogar novamente com os mesmos jogadores.
- 1.322 palavras em 12 categorias (110 ou 111 por categoria), com dicas e níveis Fácil/Médio/Difícil/Misturado.
- Não repetição da palavra enquanto existir outra disponível no conjunto de categorias e dificuldade selecionado, com histórico salvo no aparelho.
- Nomes, regras, categorias e preferências armazenados localmente.
- Modo offline, sem necessidade de cadastro, servidor, internet ou serviços de terceiros.

## Preparar o ZIP para compilar no GitHub

O arquivo **EntreSuspeitos_Android.zip** deve ficar na raiz do repositório GitHub, substituindo o ZIP anterior **com esse mesmo nome**. Se o GitHub não aceitar a substituição direta, exclua o ZIP antigo do repositório e envie o novo. Atenção a nomes de download como `(1)`.

O fluxo **Gerar APK Android** do repositório já existente continuará sendo usado. Ele precisa conter:

```yaml
- name: Extrair projeto
  run: unzip -o EntreSuspeitos_Android.zip -d .
```

**Não substitua a linha `android-actions/setup-android@v4` pela versão `@v3`.** A v4 funcionou no teste anterior.

Depois de enviar o novo ZIP e fazer o commit:

1. Acesse a guia **Actions** e selecione **Gerar APK Android**.
2. Pressione **Run workflow** e selecione `main`.
3. Quando a execução ficar verde, entre em **Artifacts**, baixe o artefato **Entre-Suspeitos-APK** e extraia o arquivo.
4. Instale `app-debug.apk` no celular Android.

### Atenção sobre atualização do APK de testes

A chave de assinatura de depuração usada nas compilações GitHub Actions pode mudar entre execuções. Se a instalação indicar **"Aplicativo não instalado"**, pode ser necessário **desinstalar o APK de testes anterior** e instalar o novo. A desinstalação pode apagar dados locais do aplicativo (nomes, preferências e histórico de palavras). No futuro, podemos implementar assinatura estável para permitir atualização direta sem esse risco.

Este ZIP contém somente o código-fonte e recursos do app; **não contém um APK pré-compilado**. A compilação e a instalação devem ser testadas no Android.

## Componentes

- `www/index.html` — estrutura do app.
- `www/style.css` — visual.
- `www/app.js` — navegação e partida.
- `www/engine.js` — sorteio, limites e raridade.
- `www/audio.js` — música e efeitos originais.
- `www/words.js` — banco de palavras local.
- `package.json` e `capacitor.config.json` — projeto Capacitor Android.

## Limitações conscientes

Modo online, chat de voz, sistema de contas, amizades, ranking, XP e painel de administrador ainda não estão implementados. Seus botões informam "em desenvolvimento"; não simulam recursos existentes. O modo offline não aplica votação eletrônica nem limite de tempo.
