# ENTRE SUSPEITOS — v4.0 (teste Android + infraestrutura online)

**Importante:** esta entrega contém o **projeto-fonte para compilar um APK**, não um APK já gerado. O modo offline foi testado em navegador simulado. A infraestrutura online foi implementada como beta, mas não foi ativada nem validada com Supabase real ou aparelhos diferentes.

## O que existe

- Offline, sem conta nem internet, 4–30 jogadores, com cartas que aparecem somente enquanto o dedo está pressionado, nomes e configuração salvos, resultado e nova rodada.
- 12 categorias e 1.322 palavras, sempre 100+ por categoria, dicas e níveis Fácil/Médio/Difícil/Misturado; histórico sem repetição até esgotar o grupo escolhido.
- Duas identidades visuais, ícone Android próprio, animações discretas, trilha instrumental **original** por síntese e efeitos sonoros opcionais; abertura com frases aleatórias e 1% para a frase especial.
- Código online para e-mail/senha, salas, amigos, chat de voz WebRTC experimental, discussões de 3 min, votação secreta de 30 s, XP, ranking, títulos iniciais, foto de perfil, denúncias e administrador.
- Servidor Supabase com regras de resultado calculadas no banco. Somente o backend distribui XP/títulos. Salas privadas não pontuam.

## NOVO: configurar servidor uma única vez por compilação

Não é mais necessário digitar endereço e chave pública do Supabase em cada aparelho. Defina as **variáveis públicas do repositório GitHub** (Settings → Secrets and variables → Actions → Variables):

| Nome | Valor |
|---|---|
| `SUPABASE_URL` | URL pública do projeto, como `https://seuprojeto.supabase.co` |
| `SUPABASE_ANON_KEY` | Chave **publishable/anon pública**, NUNCA `service_role` |

Na próxima compilação o GitHub escreve as duas informações no aplicativo. Se não configurá-las, o offline continua funcionando e o online oferece uma tela de configuração manual para desenvolvedores.

## Como gerar o APK no Android, sem computador

1. Baixe `EntreSuspeitos_Android.zip` desta entrega.
2. No repositório `https://github.com/kayssoneduardo/Kayssoneduardo-entre-suspeitos`, exclua a **versão antiga** do arquivo `EntreSuspeitos_Android.zip` que está na raiz. Envie a nova com **o mesmo nome exato**, e clique em **Commit changes**. Outros zips com nomes diferentes não são usados.
3. Abra `.github/workflows/gerar-apk.yml` no repositório e substitua seu conteúdo pela versão disponível separadamente nesta entrega. O workflow antigo do GitHub não é automaticamente substituído só porque o novo YAML está dentro do ZIP.
4. Entre em **Actions → Gerar APK Android → Run workflow → main → Run workflow**.
5. Quando ficar verde, clique no artefato `Entre-Suspeitos-V4-APK`. Baixe, extraia o ZIP do artefato e instale `app-debug.apk`.
6. Se a instalação for recusada por assinatura de depuração diferente, pode ser necessário desinstalar a versão anterior. **Desinstalar pode apagar os nomes e o histórico local**. Anote seus jogadores antes.

Para publicação oficial, será necessária uma assinatura de lançamento persistente (keystore mantida em segurança pelo proprietário). Esta compilação é apenas de teste.

## Ativar o online com Supabase

**Requer ação do proprietário e teste real.**

1. Crie uma conta em `https://supabase.com` e um projeto novo chamado `entre-suspeitos`, anotando apenas para uso pessoal a senha forte do banco.
2. No painel do projeto, abra **SQL Editor → New query** e execute `backend/01_instalar.sql` (arquivo incluído no ZIP). Faça em projeto vazio. O SQL cria as tabelas, políticas, funções, títulos iniciais e bucket de fotos. **Não execute em banco de outro aplicativo**.
3. Em **Authentication → Providers**, configure o login por e-mail e a confirmação de e-mail. Facebook OAuth requer configuração na plataforma Meta e deep link Android e **não está validado nem ativo** nesta entrega.
4. Em **Project Settings → API**, obtenha a URL e a chave pública **anon/publishable**, nunca as chaves secretas. Cadastre-as como variáveis públicas do GitHub indicadas acima.
5. Gere um novo APK e instale. Crie uma conta por e-mail no aplicativo.
6. No SQL Editor (projeto sob seu controle), consulte `select id,email from auth.users;` e identifique sua conta. Para conferir poderes de administrador, execute `insert into public.es_admins(user_id) values ('UUID-DA-SUA-CONTA') on conflict do nothing;`.
7. No aplicativo vá a **Painel administrativo → Publicar as 1.322 palavras no servidor**. Apenas o administrador consegue iniciar esta operação. Depois, teste duas contas e uma sala privada e então uma sala com quatro participantes.
8. **Não libere salas públicas nem ranking oficialmente antes dos testes de segurança, voz, reconexão, LGPD e moderação.**

## Limitações que permanecem

- **Não consegui criar nem ativar um serviço Supabase em nome do usuário.** Sem essa etapa o online não conecta jogadores.
- Chat de voz usa WebRTC P2P e STUN; pode falhar em redes móveis ou com vários jogadores sem um serviço TURN. Não foi testado entre Androids reais.
- Login do Facebook exige credenciais/configurações Meta e tratamento do retorno OAuth Android. O botão é apenas informativo até a implementação e os testes.
- Conquistas Místicas secretas e únicas e conquistas Top 10 ainda não foram ativadas; o backend já possui títulos comuns, incomuns, raros e três Lendas pioneiras.
- Fotos são públicas no perfil se o jogador optar por publicar. Ainda faltam exclusão automatizada de conta/foto, política pública e operação de atendimento ao titular de dados, exigidas antes do lançamento aberto.
- Segurança e transações SQL **não foram validadas em um banco Supabase real**; testes de interface e lógica local NÃO substituem teste de ponta a ponta.
- Dados locais podem ser perdidos se for necessário desinstalar o APK debug, pois a assinatura pode mudar entre compilações.

## Estrutura

- `www/`: aplicativo HTML/JS/CSS empacotado pelo Capacitor;
- `backend/01_instalar.sql`: esquema completo, RPCs e direitos para iniciar um Supabase NOVO;
- `branding/`: ícone e fontes PNG para Android;
- `.github/workflows/gerar-apk.yml`: workflow atualizado;
- `legal/`: rascunhos de política e termos para validação antes de lançamento;
- `tests/`: testes locais; `RELATORIO_DE_DECISOES_V4.md`: mudanças e decisões.

**Não envie senhas, tokens privilegiados ou chaves `service_role` para o ChatGPT/GitHub.**
