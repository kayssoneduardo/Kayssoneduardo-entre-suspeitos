# Relatório de decisões — Entre Suspeitos, V4.0

11/11/2026. Relatório para revisão pelo proprietário; todas as escolhas podem ser alteradas.

## O que preservei do planejamento

- Nome Entre Suspeitos; aparência Sombra (preto/vermelho) padrão e Noturno (azul/roxo), por aparelho.
- Frases da abertura: comuns 70%, incomuns 20%, raras 9%, especial “O LULA está entre nós.” 1% por abertura, com sorteio independente.
- 12 categorias, 1.322 palavras e mínimo de 100 por categoria, três dificuldades e Misturado; dicas equilibradas; sorteio sem repetição até esgotar as opções disponíveis.
- Offline: no mínimo 4 pessoas, máximo 30; de 1 impostor ao máximo inferior ao número de comuns; revelar somente ao pressionar, ocultação automática ao soltar e botão “Próximo jogador”. Sem votação ou cronômetro offline.
- Online: no mínimo 4, até 10 por sala (limite de desempenho do chat P2P nesta etapa); criar sala pública/privada, entrada por código, anfitrião inicia sem lotar se todos estiverem prontos, alteração de regra zera “Pronto”.
- Discussão online 3 minutos; sinal sonoro ao fim sem bloquear microfone. Votação secreta de 30 segundos; mesmo número de nomes que impostores, sem repetir nem votar em si; empates na última posição favorecem quem escapou.
- Desistência ou falta de voto dá derrota individual. Partidas privadas geram estatísticas, mas nunca XP ou pontos de ranking público.
- Impositor que escapar ganha individualmente; descoberto perde; os comuns só vencem se identificarem todos os impostores ainda participantes. XP individual varia conforme os votos recebidos; bônus de colaboração de 10% ao impostor descoberto que ajudou parceiro a escapar.
- Administração restrita à conta escolhida no servidor, com sugestões, denúncias e contagem de usuários/salas/partidas; nenhuma chave privilegiada embutida no APK.

## Decisões novas desta versão

| Tema | Decisão | Estado |
|---|---|---|
| Ícone | Escudo escuro com duas figuras, uma branca e uma vermelha, para Android | Criado como recurso gráfico local; ainda precisa de compilação e avaliação no aparelho |
| Tela de ajuda | Adicionar “Como jogar” ao menu principal | Implementado e testado na navegação |
| Servidor por aplicativo | Incluir URL e chave **públicas** na compilação via GitHub Actions Variables | Implementado na configuração, não ativado sem projeto Supabase |
| Banco SQL | Corrigir ambiguidade de variável XP, limitar envios por hora e proteger partes críticas | Alterado; **não testado em banco real** |
| Títulos comuns | Aprendiz de Detetive: 5 vitórias públicas como comum; Iniciante do Disfarce: 5 públicas como impostor | Lógica implementada no SQL; requer teste em Supabase |
| Título incomum | Veterano da Rodada: 20 vitórias públicas | Lógica implementada no SQL |
| Títulos raros | Sombra Invisível: vitória como impostor com zero votos; cinco vitórias seguidas em cada papel; dez vitórias seguidas no geral | Lógica implementada no SQL |
| Títulos Lenda | Primeiros do mundo a alcançar níveis 10, 30 ou 40 recebem título exclusivo e permanente | Reivindicação única transacional no SQL; requer teste de concorrência real |
| Níveis | Nível 1 + parte inteira da raiz quadrada de (XP/100). Nível 10 exige no mínimo 8.100 XP | Escolha provisória, revisável |
| Místicos | Reservar para descoberta única com condição oculta, sem revelar nome/regra antes do primeiro premiado | **Não implementado**, para não criar falsas condições visíveis no código;
| Fotos | JPEG quadrado de até 480 × 480, até 1MB, foto pública opcional, armazenamento sob o próprio ID no Supabase | Cliente e políticas implementados; faltam integração e teste real |
| Chat por voz | Preservar WebRTC P2P sem servidor TURN contratado nesta etapa, deixando controles no app | Protótipo, ainda não homologado |
| Facebook | Preservar como futuro modo de cadastro após integrar Meta OAuth e retorno Android | Pendente e explicitamente rotulado |
| Privacidade | Criar rascunhos, mas não publicar como política final sem dados do responsável | Rascunho preparado |
| Instalação | GitHub gera APK **debug**. Não embutir keystore privada no ZIP | Mantido; possível incompatibilidade entre assinaturas |

## Dificuldades reais antes do lançamento público

1. Projeto Supabase é uma conta externa e **precisa ser criado pelo proprietário**; só depois podemos configurar URL/chave pública do projeto no GitHub.
2. A instalação de `backend/01_instalar.sql` precisa ser **executada e testada no projeto real**, pois não há banco Supabase aqui.
3. Testar partidas com quatro contas reais e voz no Android, em Wi-Fi e dados móveis; avaliar TURN para grupos maiores e validar consumo de rede.
4. Login pelo Facebook requer app Meta, consentimento e redirect Android; não há credenciais válidas nesta sessão.
5. Moderar denúncias e publicar contato, termos e política de privacidade; garantir exclusão de contas e dados, segurança das sessões e proteção contra abuso/fraude.
6. Implementar títulos Top 10, condições Místicas realmente secretas e raras, proteção contra obtenção artificial de pontos, molduras e novas recompensas.
7. Preparar assinatura de lançamento persistente, versão de produção e testes Play Store antes de divulgar amplamente.

## Testes nesta entrega

- Teste Node.js: 12 categorias, 1.322 itens, distribuição por níveis, não repetição, limites de impostores e chances 70/20/9/1: **passou**.
- Testes automatizados via Chromium/Playwright: menu, configurações, cartas e resultado offline: **passou**.
- Simulações de resposta de servidor: login, criação de sala, perfil, título, ranking e convite à sala: **passou**.
- Android físico, compilação GitHub, áudio real, Supabase real, OAuth Facebook, segurança transacional: **não testados** nesta entrega.

**Não afirmar que o online está em produção. A V4 é uma base de aplicativo pronto para novos testes e ativação, não um serviço online já lançado.**
