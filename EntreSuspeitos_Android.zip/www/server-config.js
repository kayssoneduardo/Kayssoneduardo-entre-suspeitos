/* Configuração pública de conexão. O GitHub Actions pode preenchê-la durante a compilação.
   Nunca coloque neste arquivo chaves secretas (service_role), senhas ou tokens privados. */
window.ES_SERVER_CONFIG = { url: '', key: '' };
