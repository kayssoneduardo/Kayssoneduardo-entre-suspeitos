(function(){
  'use strict';
  let ctx=null,drone=null;
  function activate(){
    if(!ctx){
      const Audio=window.AudioContext||window.webkitAudioContext;
      if(!Audio)return false;
      try{ctx=new Audio();}catch{return false;}
    }
    if(ctx.state==='suspended')ctx.resume().catch(()=>{});
    return true;
  }
  function tone(freq,duration=0.16,volume=0.045,delay=0){
    if(!ctx)return;
    const start=ctx.currentTime+delay;
    const osc=ctx.createOscillator(),gain=ctx.createGain();
    osc.type='sine';osc.frequency.setValueAtTime(freq,start);
    gain.gain.setValueAtTime(0.0001,start);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002,volume),start+0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001,start+duration);
    osc.connect(gain);gain.connect(ctx.destination);osc.start(start);osc.stop(start+duration+0.03);
  }
  function effect(name,enabled){
    if(!enabled||!activate())return;
    if(name==='tap')tone(310,0.075,0.014);
    if(name==='reveal'){tone(170,0.29,0.027);tone(233,0.31,0.015,0.06);}
    if(name==='impostor'){tone(151,0.32,0.05);tone(99,0.45,0.035,0.10);}
    if(name==='finish'){tone(220,0.13,0.025);tone(277,0.15,0.025,0.16);tone(330,0.29,0.023,0.32);}
    if(name==='special'){tone(180,0.25,0.027);tone(140,0.35,0.027,0.23);}
  }
  function music(on){
    if(!on){stop();return;}
    if(!activate()||drone)return;
    try{
      const o1=ctx.createOscillator(),o2=ctx.createOscillator(),g=ctx.createGain(),filter=ctx.createBiquadFilter();
      o1.type='sine';o2.type='triangle';o1.frequency.value=65.4;o2.frequency.value=98.0;
      filter.type='lowpass';filter.frequency.value=185;
      g.gain.value=0.0;
      o1.connect(filter);o2.connect(filter);filter.connect(g);g.connect(ctx.destination);
      o1.start();o2.start();g.gain.setTargetAtTime(0.011,ctx.currentTime,0.9);
      drone={o1,o2,g};
    }catch(e){drone=null;}
  }
  function stop(){
    if(!drone||!ctx)return;
    const curr=drone;drone=null;
    curr.g.gain.setTargetAtTime(0.00001,ctx.currentTime,0.1);
    setTimeout(()=>{try{curr.o1.stop();curr.o2.stop();}catch{}},800);
  }
  window.ESAudio={activate,effect,music,stop};
})();
