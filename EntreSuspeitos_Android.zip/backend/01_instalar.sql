-- ENTRE SUSPEITOS 4.0 (CANDIDATO A TESTES) — Supabase PostgreSQL
-- Execute no SQL Editor de um projeto Supabase NOVO.
-- O projeto está inicialmente sem administrador; consulte README para autorizar sua conta.
create extension if not exists pgcrypto;

create table if not exists public.es_profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 nickname text not null default 'Suspeito',
 avatar_url text,
 equipped_title text,
 xp bigint not null default 0 check(xp>=0),
 ranking_points bigint not null default 0,
 online_wins int not null default 0,
 online_losses int not null default 0,
 private_wins int not null default 0,
 private_losses int not null default 0,
 impostor_wins int not null default 0,
 impostor_losses int not null default 0,
 common_wins int not null default 0,
 common_losses int not null default 0,
 created_at timestamptz not null default now()
);
alter table public.es_profiles add column if not exists equipped_title text;
create table if not exists public.es_admins (user_id uuid primary key references auth.users(id) on delete cascade);
create table if not exists public.es_sanctions (
 user_id uuid primary key references auth.users(id) on delete cascade,
 suspended_until timestamptz not null,
 reason text,
 updated_at timestamptz not null default now()
);
create table if not exists public.es_words (
 id bigserial primary key, category text not null, word text not null, hint text not null,
 difficulty text not null check(difficulty in ('Fácil','Médio','Difícil')),
 unique(category,word)
);
create table if not exists public.es_rooms (
 id uuid primary key default gen_random_uuid(),
 code text not null unique,
 owner_id uuid not null references auth.users(id),
 is_public boolean not null default false,
 status text not null default 'lobby' check(status in ('lobby','discussion','voting','results')),
 max_players int not null check(max_players between 4 and 10),
 impostors int not null default 1,
 categories text[] not null default '{}',
 difficulty text not null default 'Misturado',
 clue_mode text not null default 'both',
 impostors_know boolean not null default false,
 round_no int not null default 0,
 phase_ends timestamptz,
 created_at timestamptz not null default now()
);
create table if not exists public.es_members (
 room_id uuid not null references public.es_rooms(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 ready boolean not null default false,
 joined_at timestamptz not null default now(),
 seen_at timestamptz not null default now(),
 left_at timestamptz,
 primary key(room_id,user_id)
);
create table if not exists public.es_rounds (
 id uuid primary key default gen_random_uuid(),
 room_id uuid not null references public.es_rooms(id) on delete cascade,
 round_no int not null,
 word_id bigint not null references public.es_words(id),
 impostor_ids uuid[] not null,
 starter_id uuid references auth.users(id),
 started_at timestamptz not null default now(),
 finished_at timestamptz,
 unique(room_id,round_no)
);
create table if not exists public.es_round_members (
 round_id uuid not null references public.es_rounds(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 left_at timestamptz,
 primary key(round_id,user_id)
);
create table if not exists public.es_votes (
 round_id uuid not null references public.es_rounds(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 targets uuid[] not null,
 voted_at timestamptz not null default now(),
 primary key(round_id,user_id)
);
create table if not exists public.es_results (
 round_id uuid not null references public.es_rounds(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 is_impostor boolean not null,
 win boolean not null,
 voted boolean not null,
 votes_received int not null default 0,
 xp_earned int not null default 0,
 primary key(round_id,user_id)
);
create table if not exists public.es_history (
 room_id uuid not null references public.es_rooms(id) on delete cascade,
 word_id bigint not null references public.es_words(id),
 primary key(room_id,word_id)
);
create table if not exists public.es_signals (
 id bigint generated always as identity primary key,
 room_id uuid not null references public.es_rooms(id) on delete cascade,
 from_id uuid not null references auth.users(id),
 to_id uuid not null references auth.users(id),
 kind text not null check(kind in ('offer','answer','ice')),
 payload jsonb not null,
 created_at timestamptz not null default now()
);
create table if not exists public.es_friends (
 sender uuid not null references auth.users(id) on delete cascade,
 recipient uuid not null references auth.users(id) on delete cascade,
 accepted boolean not null default false,
 created_at timestamptz not null default now(),
 primary key(sender,recipient), check(sender<>recipient)
);
create table if not exists public.es_invites (
 id bigint generated always as identity primary key,
 room_id uuid not null references public.es_rooms(id) on delete cascade,
 sender uuid not null references auth.users(id),
 recipient uuid not null references auth.users(id),
 accepted boolean not null default false,
 created_at timestamptz not null default now(),
 unique(room_id,recipient)
);
create table if not exists public.es_feedback (
 id bigint generated always as identity primary key,
 reporter uuid not null references auth.users(id),
 type text not null check(type in ('categoria','palavra','reclamacao','denuncia')),
 reported_user uuid references auth.users(id),
 body text not null check(length(body) between 5 and 1500),
 status text not null default 'pendente',
 created_at timestamptz not null default now()
);

-- Impedimos leituras e gravações diretas: só RPCs autorizadas podem ver informações.
do $$declare tab text;begin
 foreach tab in array array['es_profiles','es_admins','es_sanctions','es_words','es_rooms','es_members','es_rounds','es_round_members','es_votes','es_results','es_history','es_signals','es_friends','es_invites','es_feedback'] loop
 execute format('alter table public.%I enable row level security',tab);
 end loop;
end$$;

create or replace function public.es_new_profile() returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.es_profiles(id,nickname)
 values(new.id,left(coalesce(nullif(new.raw_user_meta_data->>'nickname',''),split_part(new.email,'@',1),'Suspeito'),28))
 on conflict(id) do nothing;
 return new;
end$$;
drop trigger if exists es_profile_new on auth.users;
create trigger es_profile_new after insert on auth.users for each row execute function public.es_new_profile();
insert into public.es_profiles(id,nickname)
select id,left(coalesce(raw_user_meta_data->>'nickname',split_part(email,'@',1),'Suspeito'),28)
from auth.users on conflict(id) do nothing;

create or replace function public.es_auth() returns uuid language plpgsql stable security definer set search_path=public as $$
declare u uuid:=auth.uid();begin if u is null then raise exception 'Entre na sua conta para continuar';end if;
 if exists(select 1 from public.es_sanctions where user_id=u and suspended_until>now()) then raise exception 'Conta temporariamente suspensa pela administração';end if;return u;end$$;
create or replace function public.es_member(p_room uuid) returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.es_members where room_id=p_room and user_id=auth.uid() and left_at is null);
$$;
create or replace function public.es_is_admin() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.es_admins where user_id=auth.uid());
$$;
create or replace function public.es_public_rooms() returns jsonb language sql stable security definer set search_path=public as $$
 select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc),'[]'::jsonb)
 from (select r.id,r.code,r.max_players,r.impostors,r.difficulty,r.categories,r.clue_mode,r.impostors_know,r.created_at,
 (select count(*) from public.es_members m where m.room_id=r.id and m.left_at is null) as players
 from public.es_rooms r where r.is_public=true and r.status='lobby' order by r.created_at desc limit 60) t;
$$;
create or replace function public.es_leaderboard() returns jsonb language sql stable security definer set search_path=public as $$
 select coalesce(jsonb_agg(to_jsonb(t) order by t.ranking_points desc,t.online_wins desc),'[]'::jsonb)
 from (select nickname,avatar_url,equipped_title,ranking_points,online_wins,online_losses,xp from public.es_profiles
 order by ranking_points desc,online_wins desc limit 50) t;
$$;
create or replace function public.es_find_players(p_query text) returns jsonb language sql stable security definer set search_path=public as $$
 select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) from
 (select id,nickname from public.es_profiles where nickname ilike '%'||left(p_query,28)||'%' and id<>auth.uid() limit 15)t;
$$;
create or replace function public.es_me() returns jsonb language sql stable security definer set search_path=public as $$
 select to_jsonb(p) from public.es_profiles p where id=auth.uid();
$$;
create or replace function public.es_set_nickname(p_nick text) returns void language plpgsql security definer set search_path=public as $$
begin if length(trim(p_nick)) not between 2 and 28 then raise exception 'Use 2 a 28 caracteres';end if;
 update public.es_profiles set nickname=trim(p_nick) where id=public.es_auth();end$$;

create or replace function public.es_create(
 p_public boolean,p_max int,p_impostors int,p_categories text[],p_difficulty text,p_clue text,p_know boolean
) returns uuid language plpgsql security definer set search_path=public as $$
declare v uuid:=public.es_auth(); r uuid; code text; tries int:=0;begin
 if (select count(*) from public.es_rooms where owner_id=v and status='lobby')>=4 then
   raise exception 'Você já possui quatro salas aguardando jogadores';
 end if;
 if p_max not between 4 and 10 or p_impostors<1 or p_impostors>floor((p_max-1)/2)::int then raise exception 'Número de jogadores ou impostores inválido';end if;
 if p_difficulty not in ('Fácil','Médio','Difícil','Misturado') or p_clue not in ('both','category','hint','none') then raise exception 'Regras inválidas';end if;
 if coalesce(array_length(p_categories,1),0)<1 then raise exception 'Selecione categorias';end if;
 loop
 code:=upper(substr(encode(gen_random_bytes(5),'hex'),1,6));
 begin
 insert into public.es_rooms(code,owner_id,is_public,max_players,impostors,categories,difficulty,clue_mode,impostors_know)
 values(code,v,p_public,p_max,p_impostors,p_categories,p_difficulty,p_clue,p_know) returning id into r;
 exit;
 exception when unique_violation then tries:=tries+1;if tries>8 then raise;end if;
 end;
 end loop;
 insert into public.es_members(room_id,user_id) values(r,v);
 return r;
end$$;
create or replace function public.es_join(p_room uuid,p_code text default null) returns uuid language plpgsql security definer set search_path=public as $$
declare v uuid:=public.es_auth();r public.es_rooms%rowtype; n int;begin
 select * into r from public.es_rooms where id=p_room for update;
 if not found or r.status<>'lobby' then raise exception 'Sala indisponível';end if;
 if not r.is_public and upper(coalesce(p_code,''))<>r.code then raise exception 'Código incorreto';end if;
 select count(*) into n from public.es_members where room_id=r.id and left_at is null;
 if n>=r.max_players and not exists(select 1 from public.es_members where room_id=r.id and user_id=v and left_at is null) then raise exception 'Sala cheia';end if;
 insert into public.es_members(room_id,user_id,ready,left_at) values(r.id,v,false,null)
 on conflict(room_id,user_id) do update set left_at=null,ready=false,seen_at=now();
 update public.es_members set ready=false where room_id=r.id;
 return r.id;
end$$;

create or replace function public.es_rejoin(p_room uuid) returns uuid language plpgsql security definer set search_path=public as $$
declare r public.es_rooms%rowtype;begin
 select * into r from public.es_rooms where id=p_room for update;
 if not found or not exists(select 1 from public.es_members where room_id=p_room and user_id=public.es_auth()) then raise exception 'Você não participou dessa sala';end if;
 if r.status='results' or (r.status='voting' and now()>r.phase_ends) then raise exception 'Prazo de retorno encerrado';end if;
 update public.es_members set left_at=null,seen_at=now() where room_id=p_room and user_id=public.es_auth();
 return p_room;
end$$;

create or replace function public.es_join_code(p_code text) returns uuid language plpgsql security definer set search_path=public as $$
declare r uuid;begin select id into r from public.es_rooms where code=upper(trim(p_code)) and status='lobby';
 if r is null then raise exception 'Código não encontrado';end if;
 return public.es_join(r,p_code);end$$;
create or replace function public.es_rules(p_room uuid,p_max int,p_impostors int,p_categories text[],p_difficulty text,p_clue text,p_know boolean) returns void language plpgsql security definer set search_path=public as $$
declare n int;begin
 if not exists(select 1 from public.es_rooms where id=p_room and owner_id=public.es_auth() and status='lobby') then raise exception 'Somente o anfitrião pode mudar regras no lobby';end if;
 select count(*) into n from public.es_members where room_id=p_room and left_at is null;
 if p_max not between greatest(4,n) and 10 or p_impostors<1 or p_impostors>floor((p_max-1)/2)::int
 or coalesce(array_length(p_categories,1),0)<1 or p_difficulty not in ('Fácil','Médio','Difícil','Misturado')
 or p_clue not in ('both','category','hint','none') then raise exception 'Configuração inválida';end if;
 update public.es_rooms set max_players=p_max,impostors=p_impostors,categories=p_categories,difficulty=p_difficulty,clue_mode=p_clue,impostors_know=p_know where id=p_room;
 update public.es_members set ready=false where room_id=p_room and left_at is null;
end$$;
create or replace function public.es_ready(p_room uuid,p_ready boolean) returns void language plpgsql security definer set search_path=public as $$
begin if not public.es_member(p_room) then raise exception 'Você não faz parte da sala';end if;
 if not exists(select 1 from public.es_rooms where id=p_room and status='lobby') then raise exception 'Partida já iniciada';end if;
 update public.es_members set ready=p_ready,seen_at=now() where room_id=p_room and user_id=public.es_auth();end$$;
create or replace function public.es_touch(p_room uuid) returns void language plpgsql security definer set search_path=public as $$
begin
 update public.es_members set seen_at=now() where room_id=p_room and user_id=public.es_auth() and left_at is null;
 update public.es_rooms r set owner_id=(select m.user_id from public.es_members m where m.room_id=p_room and m.left_at is null and m.seen_at>now()-interval '20 seconds' order by m.joined_at limit 1)
 where r.id=p_room and not exists(select 1 from public.es_members m where m.room_id=p_room and m.user_id=r.owner_id and m.left_at is null and m.seen_at>now()-interval '20 seconds')
 and exists(select 1 from public.es_members m where m.room_id=p_room and m.left_at is null and m.seen_at>now()-interval '20 seconds');
end$$;
create or replace function public.es_room_view(p_room uuid) returns jsonb language plpgsql stable security definer set search_path=public as $$
declare r public.es_rooms%rowtype;rd public.es_rounds%rowtype; w public.es_words%rowtype;v uuid:=public.es_auth();
 j jsonb; people jsonb;me jsonb:='{}';results jsonb:='[]';begin
 if not public.es_member(p_room) then raise exception 'Você não faz parte da sala';end if;
 select * into r from public.es_rooms where id=p_room;
 select coalesce(jsonb_agg(jsonb_build_object('id',m.user_id,'nick',p.nickname,'avatar',p.avatar_url,'title',p.equipped_title,'ready',m.ready,'active',m.left_at is null,'online',m.seen_at>now()-interval '20 seconds') order by m.joined_at),'[]') into people
 from public.es_members m join public.es_profiles p on p.id=m.user_id where m.room_id=p_room;
 if r.status<>'lobby' then
 select * into rd from public.es_rounds where room_id=p_room and round_no=r.round_no;
 if found then
 select * into w from public.es_words where id=rd.word_id;
 if r.status='results' then
  select coalesce(jsonb_agg(jsonb_build_object('user',x.user_id,'impostor',x.is_impostor,'win',x.win,'xp',x.xp_earned,'votes',x.votes_received)),'[]') into results
  from public.es_results x where x.round_id=rd.id;
  me=jsonb_build_object('word',w.word,'category',w.category,'impostors',rd.impostor_ids);
 else
  me=jsonb_build_object('impostor',v=any(rd.impostor_ids),
   'category',case when v<>all(rd.impostor_ids) or r.clue_mode in ('both','category') then w.category else null end,
   'hint',case when v=any(rd.impostor_ids) and r.clue_mode in ('both','hint') then w.hint else null end,
   'word',case when v<>all(rd.impostor_ids) then w.word else null end,
   'partners',case when v=any(rd.impostor_ids) and r.impostors_know then to_jsonb(array_remove(rd.impostor_ids,v)) else '[]'::jsonb end,
   'voted',exists(select 1 from public.es_votes where round_id=rd.id and user_id=v));
 end if;
 end if;
 end if;
 return jsonb_build_object('id',r.id,'code',r.code,'owner',r.owner_id,'public',r.is_public,'status',r.status,
 'max',r.max_players,'impostors',r.impostors,'categories',r.categories,'difficulty',r.difficulty,
 'clue',r.clue_mode,'know',r.impostors_know,'phaseEnds',r.phase_ends,'round',r.round_no,
 'players',people,'me',me,'starter',case when r.status='lobby' then null else rd.starter_id end,'results',results);
end$$;
create or replace function public.es_start(p_room uuid) returns void language plpgsql security definer set search_path=public as $$
declare r public.es_rooms%rowtype; n int;wid bigint;imp uuid[];first_id uuid;v uuid:=public.es_auth();begin
 select * into r from public.es_rooms where id=p_room for update;
 if not found or r.owner_id<>v or r.status<>'lobby' then raise exception 'Apenas o anfitrião pode iniciar';end if;
 select count(*) into n from public.es_members where room_id=p_room and left_at is null;
 if n<4 or r.impostors>floor((n-1)/2)::int then raise exception 'Ajuste o número de impostores para os participantes';end if;
 if exists(select 1 from public.es_members where room_id=p_room and left_at is null and ready=false) then raise exception 'Todos precisam estar prontos';end if;
 select w.id into wid from public.es_words w where w.category=any(r.categories) and (r.difficulty='Misturado' or w.difficulty=r.difficulty)
 and not exists(select 1 from public.es_history h where h.room_id=p_room and h.word_id=w.id) order by random() limit 1;
 if wid is null then
 delete from public.es_history where room_id=p_room;
 select w.id into wid from public.es_words w where w.category=any(r.categories) and (r.difficulty='Misturado' or w.difficulty=r.difficulty) order by random() limit 1;
 end if;
 if wid is null then raise exception 'O banco online ainda não foi publicado pelo administrador';end if;
 insert into public.es_history(room_id,word_id) values(p_room,wid) on conflict do nothing;
 select array_agg(user_id) into imp from (select user_id from public.es_members where room_id=p_room and left_at is null order by random() limit r.impostors)t;
 select user_id into first_id from public.es_members where room_id=p_room and left_at is null order by random() limit 1;
 update public.es_rooms set status='discussion',round_no=round_no+1,phase_ends=now()+interval '3 minutes' where id=p_room returning * into r;
 insert into public.es_rounds(room_id,round_no,word_id,impostor_ids,starter_id) values(p_room,r.round_no,wid,imp,first_id);
 insert into public.es_round_members(round_id,user_id) select rd.id,m.user_id from public.es_rounds rd join public.es_members m on m.room_id=rd.room_id and m.left_at is null where rd.room_id=p_room and rd.round_no=r.round_no;
 update public.es_members set ready=false where room_id=p_room;
 delete from public.es_signals where room_id=p_room and created_at<now()-interval '20 minutes';
end$$;
create or replace function public.es_begin_vote(p_room uuid) returns void language plpgsql security definer set search_path=public as $$
declare r public.es_rooms%rowtype;begin
 if not public.es_member(p_room) then raise exception 'Você não faz parte da sala';end if;
 select * into r from public.es_rooms where id=p_room for update;
 if r.status='voting' or r.status='results' then return;end if;
 if r.status<>'discussion' or now()<r.phase_ends then raise exception 'A discussão ainda está em andamento';end if;
 update public.es_rooms set status='voting',phase_ends=now()+interval '30 seconds' where id=p_room;
end$$;
create or replace function public.es_vote(p_room uuid,p_targets uuid[]) returns void language plpgsql security definer set search_path=public as $$
declare r public.es_rooms%rowtype; rd uuid; v uuid:=public.es_auth();begin
 if not public.es_member(p_room) then raise exception 'Você não faz parte da sala';end if;
 select * into r from public.es_rooms where id=p_room;
 if r.status<>'voting' or now()>r.phase_ends then raise exception 'Votação encerrada';end if;
 if array_length(p_targets,1)<>r.impostors then raise exception 'Escolha exatamente o número de suspeitos';end if;
 if v=any(p_targets) then raise exception 'Não é permitido votar em si mesmo';end if;
 if (select count(distinct x) from unnest(p_targets)x)<>r.impostors then raise exception 'Não repita nomes';end if;
 if exists(select 1 from unnest(p_targets)t where not exists(select 1 from public.es_members m where m.room_id=p_room and m.user_id=t and m.left_at is null and m.seen_at>now()-interval '20 seconds')) then raise exception 'Escolha jogadores ativos';end if;
 select id into rd from public.es_rounds where room_id=p_room and round_no=r.round_no;
 insert into public.es_votes(round_id,user_id,targets) values(rd,v,p_targets) on conflict(round_id,user_id) do nothing;
 update public.es_members set seen_at=now() where room_id=p_room and user_id=v;
end$$;
create or replace function public.es_finalize(p_room uuid) returns boolean language plpgsql security definer set search_path=public as $$
declare r public.es_rooms%rowtype; rd public.es_rounds%rowtype; candidate record; n_active int; n_voted int; slots int;
 discovered uuid[]:='{}'; n_same int; points int; prev int:=null; grp int:=0;
 is_imp boolean; won boolean; voted boolean;correct int; got int;eligible int; v_xp int; team_common boolean; partner_won boolean; v uuid:=public.es_auth();begin
 if not public.es_member(p_room) then raise exception 'Você não faz parte da sala';end if;
 select * into r from public.es_rooms where id=p_room for update;
 if r.status='results' then return true;end if;
 if r.status<>'voting' then return false;end if;
 select * into rd from public.es_rounds where room_id=p_room and round_no=r.round_no;
 select count(*) into n_active from public.es_round_members rm join public.es_members m on m.room_id=p_room and m.user_id=rm.user_id where rm.round_id=rd.id and m.left_at is null and m.seen_at>now()-interval '20 seconds';
 select count(*) into n_voted from public.es_votes where round_id=rd.id;
 if now()<r.phase_ends and n_voted<n_active then return false;end if;
 -- Para que uma desconexão não perca seu prazo de retorno, aguardamos sempre até os 30s se houver alguém desconectado.
 if now()<r.phase_ends and exists(select 1 from public.es_round_members rm join public.es_members m on m.room_id=p_room and m.user_id=rm.user_id
 where rm.round_id=rd.id and m.left_at is null and m.seen_at<=now()-interval '20 seconds') then return false;end if;
 -- Votos de ausentes e não votantes são excluídos; empate pela última vaga não seleciona ninguém daquele grupo.
 select count(*) into slots from unnest(rd.impostor_ids) i where exists(select 1 from public.es_votes v where v.round_id=rd.id and v.user_id=i);
 -- Mantém as vagas originais; desistentes não podem ser escolhidos como suspeitos.
 slots:=r.impostors;
 for candidate in
 select t.user_id,count(*)::int as amount from public.es_votes v cross join lateral unnest(v.targets)t(user_id)
 join public.es_votes vv on vv.round_id=v.round_id and vv.user_id=v.user_id
 where v.round_id=rd.id group by t.user_id order by amount desc
 loop
 if prev is distinct from candidate.amount then
  select count(*) into grp from (select z.user_id,count(*) as cnt from public.es_votes vs cross join lateral unnest(vs.targets)z(user_id)
   where vs.round_id=rd.id group by z.user_id having count(*)=candidate.amount) q;
  if grp>slots then exit;end if;
  slots:=slots-grp;prev:=candidate.amount;
 end if;
 discovered:=array_append(discovered,candidate.user_id);
 if slots=0 and (select count(*) from unnest(discovered))>=r.impostors then exit;end if;
 end loop;
 -- Jogadores comuns só vencem se todos os impostores QUE VOTARAM foram identificados.
 team_common:=not exists(select 1 from unnest(rd.impostor_ids) i
 where exists(select 1 from public.es_votes v where v.round_id=rd.id and v.user_id=i)
 and not(i=any(discovered)));
 for candidate in select rm.user_id from public.es_round_members rm where rm.round_id=rd.id loop
  is_imp:=candidate.user_id=any(rd.impostor_ids);
  voted:=exists(select 1 from public.es_votes v where v.round_id=rd.id and v.user_id=candidate.user_id);
  select count(*)::int into got from public.es_votes v where v.round_id=rd.id and candidate.user_id=any(v.targets);
  select count(*)::int into eligible from public.es_votes v where v.round_id=rd.id and v.user_id<>candidate.user_id;
  won:=voted and exists(select 1 from public.es_members m where m.room_id=p_room and m.user_id=candidate.user_id and m.left_at is null and m.seen_at>now()-interval '20 seconds')
   and (case when is_imp then not(candidate.user_id=any(discovered)) else team_common end);
  if not voted then v_xp:=0;
  elsif is_imp then
   v_xp:=case when won then 20+round(130*(1-got::numeric/greatest(1,eligible)))::int else 20+round(30*(1-got::numeric/greatest(1,eligible)))::int end;
   if not won and exists(select 1 from unnest(rd.impostor_ids) i where i<>candidate.user_id and not(i=any(discovered)) and exists(select 1 from public.es_votes where round_id=rd.id and user_id=i)) then
    v_xp:=v_xp+round(v_xp*.10)::int;
   end if;
  else
   select count(*)::int into correct from public.es_votes v cross join lateral unnest(v.targets)t(uid)
   where v.round_id=rd.id and v.user_id=candidate.user_id and t.uid=any(rd.impostor_ids);
   v_xp:=20+15*correct+case when won then 40 else 0 end;
  end if;
  v_xp:=greatest(0,v_xp);
  insert into public.es_results(round_id,user_id,is_impostor,win,voted,votes_received,xp_earned)
  values(rd.id,candidate.user_id,is_imp,won,voted,got,case when r.is_public then v_xp else 0 end);
  update public.es_profiles as prof set
   xp=prof.xp+case when r.is_public then v_xp else 0 end,
   ranking_points=ranking_points+case when not r.is_public then 0 when won then 25 else -10 end,
   online_wins=online_wins+case when r.is_public and won then 1 else 0 end,
   online_losses=online_losses+case when r.is_public and not won then 1 else 0 end,
   private_wins=private_wins+case when not r.is_public and won then 1 else 0 end,
   private_losses=private_losses+case when not r.is_public and not won then 1 else 0 end,
   impostor_wins=impostor_wins+case when is_imp and won then 1 else 0 end,
   impostor_losses=impostor_losses+case when is_imp and not won then 1 else 0 end,
   common_wins=common_wins+case when not is_imp and won then 1 else 0 end,
   common_losses=common_losses+case when not is_imp and not won then 1 else 0 end
  where id=candidate.user_id;
  -- Progresso e títulos são concedidos somente pelo servidor e apenas em partidas públicas.
  if r.is_public then
    perform public.es_award_progress(candidate.user_id,is_imp,won,got);
  end if;
 end loop;
 update public.es_rounds set finished_at=now() where id=rd.id;
 update public.es_rooms set status='results',phase_ends=null where id=p_room;
 return true;
end$$;
create or replace function public.es_next(p_room uuid) returns void language plpgsql security definer set search_path=public as $$
begin if not exists(select 1 from public.es_rooms where id=p_room and owner_id=public.es_auth() and status='results') then raise exception 'Somente o anfitrião pode começar a próxima rodada';end if;
 delete from public.es_members where room_id=p_room and left_at is not null;
 update public.es_members set ready=false where room_id=p_room;
 update public.es_rooms set status='lobby',phase_ends=null where id=p_room;
end$$;
create or replace function public.es_leave(p_room uuid) returns void language plpgsql security definer set search_path=public as $$
declare v uuid:=public.es_auth();r public.es_rooms%rowtype;newowner uuid;begin
 select * into r from public.es_rooms where id=p_room for update;
 update public.es_members set left_at=now(),ready=false where room_id=p_room and user_id=v;
 if r.status='lobby' then delete from public.es_members where room_id=p_room and user_id=v;end if;
 if r.owner_id=v then
 select user_id into newowner from public.es_members where room_id=p_room and left_at is null order by joined_at limit 1;
 if newowner is not null then update public.es_rooms set owner_id=newowner where id=p_room;
 elsif r.status='lobby' then delete from public.es_rooms where id=p_room;
 -- Sala em andamento: preserve a rodada e os dados da classificação até uma reconexão/encerramento.
 end if;
 end if;
end$$;
create or replace function public.es_signal_send(p_room uuid,p_to uuid,p_kind text,p_payload jsonb) returns void language plpgsql security definer set search_path=public as $$
begin if not public.es_member(p_room) or not exists(select 1 from public.es_members where room_id=p_room and user_id=p_to and left_at is null) then raise exception 'Participante inválido';end if;
 if p_kind not in ('offer','answer','ice') or length(p_payload::text)>20000 then raise exception 'Sinal inválido';end if;
 if (select count(*) from public.es_signals where from_id=auth.uid() and created_at>now()-interval '1 minute')>500 then
   raise exception 'Muitos sinais de voz. Aguarde um momento';end if;
 insert into public.es_signals(room_id,from_id,to_id,kind,payload) values(p_room,public.es_auth(),p_to,p_kind,p_payload);end$$;
create or replace function public.es_signal_poll(p_room uuid,p_after bigint default 0) returns jsonb language sql stable security definer set search_path=public as $$
 select case when public.es_member(p_room) then
 coalesce((select jsonb_agg(to_jsonb(t) order by t.id) from
 (select s.id,s.from_id,s.kind,s.payload from public.es_signals s where s.room_id=p_room and s.to_id=auth.uid() and s.id>p_after
 and s.created_at>now()-interval '10 minutes' order by s.id limit 100)t),'[]'::jsonb)
 else '[]'::jsonb end;
$$;
create or replace function public.es_friend_send(p_to uuid) returns void language plpgsql security definer set search_path=public as $$
begin if p_to=public.es_auth() then raise exception 'Não pode adicionar a si mesmo';end if;
 insert into public.es_friends(sender,recipient) values(public.es_auth(),p_to) on conflict do nothing;end$$;
create or replace function public.es_friend_accept(p_from uuid) returns void language plpgsql security definer set search_path=public as $$
begin update public.es_friends set accepted=true where recipient=public.es_auth() and sender=p_from;end$$;
create or replace function public.es_friend_list() returns jsonb language sql stable security definer set search_path=public as $$
 select coalesce(jsonb_agg(jsonb_build_object('id',case when f.sender=auth.uid() then f.recipient else f.sender end,
 'nickname',p.nickname,'accepted',f.accepted,'incoming',f.recipient=auth.uid())),'[]'::jsonb)
 from public.es_friends f join public.es_profiles p on p.id=case when f.sender=auth.uid() then f.recipient else f.sender end
 where f.sender=auth.uid() or f.recipient=auth.uid();
$$;

create or replace function public.es_invite_send(p_room uuid,p_to uuid) returns void language plpgsql security definer set search_path=public as $$
begin
 if not public.es_member(p_room) then raise exception 'Você não está na sala';end if;
 if not exists(select 1 from public.es_rooms where id=p_room and status='lobby') then raise exception 'A partida já começou';end if;
 if not exists(select 1 from public.es_friends where accepted=true and ((sender=auth.uid() and recipient=p_to) or (recipient=auth.uid() and sender=p_to))) then raise exception 'Convide apenas amigos';end if;
 insert into public.es_invites(room_id,sender,recipient) values(p_room,public.es_auth(),p_to) on conflict(room_id,recipient) do update set accepted=false,created_at=now(),sender=excluded.sender;
end$$;
create or replace function public.es_invite_list() returns jsonb language sql stable security definer set search_path=public as $$
 select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc),'[]'::jsonb) from
 (select i.id,i.room_id,i.created_at,r.code,r.is_public,r.status,p.nickname as from_nick
 from public.es_invites i join public.es_rooms r on r.id=i.room_id join public.es_profiles p on p.id=i.sender
 where i.recipient=auth.uid() and i.accepted=false and r.status='lobby' order by i.created_at desc limit 30)t;
$$;
create or replace function public.es_invite_accept(p_invite bigint) returns uuid language plpgsql security definer set search_path=public as $$
declare i public.es_invites%rowtype; r public.es_rooms%rowtype;begin
 select * into i from public.es_invites where id=p_invite and recipient=public.es_auth() and accepted=false;
 if not found then raise exception 'Convite não encontrado';end if;
 select * into r from public.es_rooms where id=i.room_id;
 perform public.es_join(r.id,r.code);
 update public.es_invites set accepted=true where id=p_invite;
 return r.id;
end$$;
create or replace function public.es_feedback_send(p_type text,p_body text,p_target uuid default null) returns void language plpgsql security definer set search_path=public as $$
begin if p_type not in ('categoria','palavra','reclamacao','denuncia') or length(trim(p_body)) not between 5 and 1500 then raise exception 'Formulário inválido';end if;
 if (select count(*) from public.es_feedback where reporter=public.es_auth() and created_at>now()-interval '1 hour')>=10 then
  raise exception 'Aguarde antes de enviar novas mensagens';end if;
 insert into public.es_feedback(reporter,type,body,reported_user) values(public.es_auth(),p_type,trim(p_body),p_target);
end$$;
create or replace function public.es_admin_dashboard() returns jsonb language plpgsql stable security definer set search_path=public as $$
begin if not public.es_is_admin() then raise exception 'Acesso restrito';end if;
 return jsonb_build_object('contas',(select count(*) from public.es_profiles),'salas',(select count(*) from public.es_rooms where status<>'results'),
 'jogadoresOnline',(select count(distinct user_id) from public.es_members where left_at is null and seen_at>now()-interval '30 seconds'),
 'partidas',(select count(*) from public.es_rounds),'pendencias',(select count(*) from public.es_feedback where status='pendente'),
 'solicitacoes',(select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) from (select id,type,body,reporter,reported_user,status,created_at
 from public.es_feedback order by created_at desc limit 80)t));
end$$;
create or replace function public.es_admin_resolve(p_id bigint,p_status text) returns void language plpgsql security definer set search_path=public as $$
begin if not public.es_is_admin() or p_status not in ('pendente','em analise','resolvido','rejeitado') then raise exception 'Operação negada';end if;
 update public.es_feedback set status=p_status where id=p_id;end$$;

create or replace function public.es_admin_sanction(p_target uuid,p_days int,p_reason text) returns void language plpgsql security definer set search_path=public as $$
begin
 if not public.es_is_admin() then raise exception 'Acesso restrito';end if;
 if p_target=auth.uid() or exists(select 1 from public.es_admins where user_id=p_target) then raise exception 'Não é permitido suspender administrador';end if;
 if p_days not between 1 and 365 or length(trim(p_reason))<5 then raise exception 'Informe período e justificativa válidos';end if;
 insert into public.es_sanctions(user_id,suspended_until,reason) values(p_target,now()+make_interval(days=>p_days),left(p_reason,500))
 on conflict(user_id) do update set suspended_until=excluded.suspended_until,reason=excluded.reason,updated_at=now();
end$$;
create or replace function public.es_admin_unsanction(p_target uuid) returns void language plpgsql security definer set search_path=public as $$
begin if not public.es_is_admin() then raise exception 'Acesso restrito';end if;
 delete from public.es_sanctions where user_id=p_target;end$$;
create or replace function public.es_admin_seed(p_entries jsonb) returns int language plpgsql security definer set search_path=public as $$
declare n int;begin if not public.es_is_admin() then raise exception 'Somente o administrador publica palavras';end if;
 if jsonb_typeof(p_entries)<>'array' or jsonb_array_length(p_entries)>160 then raise exception 'Envie até 160 palavras por lote';end if;
 insert into public.es_words(category,word,hint,difficulty)
 select left(x.category,90),left(x.word,120),left(x.hint,200),x.difficulty
 from jsonb_to_recordset(p_entries) as x(category text,word text,hint text,difficulty text)
 where x.category is not null and x.word is not null and x.hint is not null and x.difficulty in ('Fácil','Médio','Difícil')
 on conflict(category,word) do update set hint=excluded.hint,difficulty=excluded.difficulty;
 get diagnostics n=row_count;return n;
end$$;

-- SISTEMA DE TÍTULOS — V4
-- As tabelas são protegidas por RLS, sem permissão direta para clientes.
create table if not exists public.es_titles(
 code text primary key,
 name text not null,
 rarity text not null check(rarity in ('comum','incomum','raro','lenda','mistico')),
 description text not null,
 world_unique boolean not null default false,
 hidden boolean not null default false
);
create table if not exists public.es_user_titles(
 user_id uuid not null references auth.users(id) on delete cascade,
 title_code text not null references public.es_titles(code),
 acquired_at timestamptz not null default now(),
 primary key(user_id,title_code)
);
create table if not exists public.es_title_claims(
 title_code text primary key references public.es_titles(code),
 user_id uuid not null references auth.users(id),
 claimed_at timestamptz not null default now()
);
create table if not exists public.es_progress(
 user_id uuid primary key references auth.users(id) on delete cascade,
 streak_all int not null default 0,
 streak_impostor int not null default 0,
 streak_common int not null default 0
);
alter table public.es_profiles add column if not exists equipped_title text;

insert into public.es_titles(code,name,rarity,description,world_unique,hidden) values
 ('detetive_iniciante','Aprendiz de Detetive','comum','Vença cinco partidas públicas como jogador comum.',false,false),
 ('disfarce_iniciante','Iniciante do Disfarce','comum','Vença cinco partidas públicas como impostor.',false,false),
 ('veterano','Veterano da Rodada','incomum','Conquiste vinte vitórias públicas.',false,false),
 ('sem_votos','Sombra Invisível','raro','Vença uma partida pública como impostor sem receber nenhum voto.',false,false),
 ('cinco_impostor','Mestre do Disfarce V','raro','Conquiste cinco vitórias seguidas no papel de impostor.',false,false),
 ('cinco_comum','Detetive Incansável V','raro','Conquiste cinco vitórias seguidas no papel de jogador comum.',false,false),
 ('dez_seguidas','Implacável X','raro','Conquiste dez vitórias públicas consecutivas, em qualquer papel.',false,false),
 ('primeiro_nivel10','Pioneiro do Décimo Nível','lenda','Primeiro jogador do mundo a atingir o nível 10.',true,false),
 ('primeiro_nivel30','Pioneiro do Trigésimo Nível','lenda','Primeiro jogador do mundo a atingir o nível 30.',true,false),
 ('primeiro_nivel40','Pioneiro do Quadragésimo Nível','lenda','Primeiro jogador do mundo a atingir o nível 40.',true,false)
on conflict(code) do update set name=excluded.name,rarity=excluded.rarity,description=excluded.description;

-- Esta função não deve ter EXECUTE para authenticated. Só será chamada pelo fechamento da rodada.
create or replace function public.es_award_progress(p_user uuid,p_impostor boolean,p_won boolean,p_votes int)
returns void language plpgsql security definer set search_path=public as $$
declare prog public.es_progress%rowtype; pr public.es_profiles%rowtype; code text; lvl int; public_role_wins int;
begin
 insert into public.es_progress(user_id) values(p_user) on conflict do nothing;
 update public.es_progress set
  streak_all=case when p_won then streak_all+1 else 0 end,
  streak_impostor=case when p_impostor then (case when p_won then streak_impostor+1 else 0 end) else streak_impostor end,
  streak_common=case when not p_impostor then (case when p_won then streak_common+1 else 0 end) else streak_common end
 where user_id=p_user returning * into prog;
 select * into pr from public.es_profiles where id=p_user;
 select count(*) into public_role_wins
 from public.es_results rs join public.es_rounds rd on rd.id=rs.round_id
 join public.es_rooms room on room.id=rd.room_id
 where rs.user_id=p_user and rs.win and not rs.is_impostor and room.is_public;
 if public_role_wins>=5 then
  insert into public.es_user_titles(user_id,title_code) values(p_user,'detetive_iniciante') on conflict do nothing;
 end if;
 select count(*) into public_role_wins
 from public.es_results rs join public.es_rounds rd on rd.id=rs.round_id
 join public.es_rooms room on room.id=rd.room_id
 where rs.user_id=p_user and rs.win and rs.is_impostor and room.is_public;
 if public_role_wins>=5 then
  insert into public.es_user_titles(user_id,title_code) values(p_user,'disfarce_iniciante') on conflict do nothing;
 end if;
 if pr.online_wins>=20 then
  insert into public.es_user_titles(user_id,title_code) values(p_user,'veterano') on conflict do nothing;
 end if;
 if p_impostor and p_won and p_votes=0 then
  insert into public.es_user_titles(user_id,title_code) values(p_user,'sem_votos') on conflict do nothing;
 end if;
 if prog.streak_impostor>=5 then
  insert into public.es_user_titles(user_id,title_code) values(p_user,'cinco_impostor') on conflict do nothing;
 end if;
 if prog.streak_common>=5 then
  insert into public.es_user_titles(user_id,title_code) values(p_user,'cinco_comum') on conflict do nothing;
 end if;
 if prog.streak_all>=10 then
  insert into public.es_user_titles(user_id,title_code) values(p_user,'dez_seguidas') on conflict do nothing;
 end if;
 -- Nível é recalculado pela experiência pública: XP para nível N = 100*(N-1)^2.
 lvl=1+floor(sqrt(greatest(0,pr.xp)::numeric/100))::int;
 for code in select t.code from public.es_titles t where
  (t.code='primeiro_nivel10' and lvl>=10) or
  (t.code='primeiro_nivel30' and lvl>=30) or
  (t.code='primeiro_nivel40' and lvl>=40)
 loop
  -- a chave primária da tabela de reivindicações garante unicidade até com partidas simultâneas.
  with won as (
   insert into public.es_title_claims(title_code,user_id) values(code,p_user)
   on conflict do nothing returning title_code
  )
  insert into public.es_user_titles(user_id,title_code)
   select p_user,title_code from won on conflict do nothing;
 end loop;
end$$;

create or replace function public.es_my_titles() returns jsonb
language sql stable security definer set search_path=public as $$
 select coalesce(jsonb_agg(jsonb_build_object(
 'code',t.code,'name',t.name,'rarity',t.rarity,'description',t.description,
 'equipped',p.equipped_title=t.code,'unique',t.world_unique,
 'acquired_at',ut.acquired_at) order by ut.acquired_at desc),'[]'::jsonb)
 from public.es_user_titles ut join public.es_titles t on t.code=ut.title_code
 join public.es_profiles p on p.id=ut.user_id
 where ut.user_id=auth.uid();
$$;
create or replace function public.es_equip_title(p_title text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not exists (select 1 from public.es_user_titles where user_id=public.es_auth() and title_code=p_title) then
   raise exception 'Você ainda não conquistou esse título';
 end if;
 update public.es_profiles set equipped_title=p_title where id=auth.uid();
end$$;
create or replace function public.es_title_catalog() returns jsonb
language sql stable security definer set search_path=public as $$
 select coalesce(jsonb_agg(jsonb_build_object('code',t.code,'name',t.name,'rarity',t.rarity,
 'description',t.description,'world_unique',t.world_unique,
 'claimed',case when t.world_unique then exists(select 1 from public.es_title_claims c where c.title_code=t.code) else null end)
 order by t.rarity,t.name),'[]'::jsonb)
 from public.es_titles t where not t.hidden or exists(select 1 from public.es_user_titles ut where ut.title_code=t.code);
$$;

-- Protege dados e impõe que clientes usem apenas funções autorizadas.
do $$declare t text;begin
 foreach t in array array['es_titles','es_user_titles','es_title_claims','es_progress'] loop
  execute format('alter table public.%I enable row level security',t);
 end loop;
end$$;

-- FOTOS PÚBLICAS E OPCIONAIS DE PERFIL
-- Instalação em projeto Supabase novo ou existente.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
 values('es-avatars','es-avatars',true,1048576,array['image/jpeg'])
 on conflict(id) do update set public=true,file_size_limit=1048576,allowed_mime_types=array['image/jpeg'];

-- Limpa somente políticas com nomes reservados a este aplicativo.
drop policy if exists "es_avatar_insert" on storage.objects;
drop policy if exists "es_avatar_update" on storage.objects;
drop policy if exists "es_avatar_select" on storage.objects;
drop policy if exists "es_avatar_delete" on storage.objects;
create policy "es_avatar_insert" on storage.objects for insert to authenticated
 with check(bucket_id='es-avatars' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "es_avatar_update" on storage.objects for update to authenticated
 using(bucket_id='es-avatars' and (storage.foldername(name))[1]=auth.uid()::text)
 with check(bucket_id='es-avatars' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "es_avatar_delete" on storage.objects for delete to authenticated
 using(bucket_id='es-avatars' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "es_avatar_select" on storage.objects for select to authenticated
 using(bucket_id='es-avatars');

create or replace function public.es_set_avatar(p_path text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if p_path<>(public.es_auth()::text||'/avatar.jpg') then
  raise exception 'Caminho de foto inválido';
 end if;
 if not exists(select 1 from storage.objects where bucket_id='es-avatars' and name=p_path) then
  raise exception 'Foto não encontrada';
 end if;
 update public.es_profiles set avatar_url=p_path where id=auth.uid();
end$$;

-- RPCs são executadas por usuários autenticados; nenhum cliente recebe permissão direta nas tabelas.
DO $$declare tab text;begin
 foreach tab in array array['es_profiles','es_admins','es_sanctions','es_words','es_rooms','es_members','es_rounds','es_round_members','es_votes','es_results','es_history','es_signals','es_friends','es_invites','es_feedback','es_titles','es_user_titles','es_title_claims','es_progress'] loop
 execute format('revoke all on public.%I from anon,authenticated',tab);
 end loop;
end$$;
grant usage on schema public to authenticated;
DO $$declare f record;begin
 for f in select p.oid::regprocedure::text as signature from pg_proc p join pg_namespace n on n.oid=p.pronamespace
 where n.nspname='public' and p.proname like 'es_%' loop
 execute 'revoke all on function '||f.signature||' from public,anon';
 execute 'grant execute on function '||f.signature||' to authenticated';
 end loop;
end$$;

-- Nunca exponha a rotina interna que distribui títulos aos usuários.
revoke all on function public.es_award_progress(uuid,boolean,boolean,int) from public,anon,authenticated;
