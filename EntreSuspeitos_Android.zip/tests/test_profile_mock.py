from playwright.sync_api import sync_playwright
from pathlib import Path
import re
base=Path(__file__).resolve().parents[1]/'www'
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 html=re.sub(r'<script src="[^"]+"></script>','', (base/'index.html').read_text())
 page.set_content(html);page.add_style_tag(content=(base/'style.css').read_text())
 page.evaluate("""window.fetch=async(url,opt)=>{
 const path=String(url);
 let d=null;
 if(path.includes('/auth/v1/token'))d={access_token:'jwt',refresh_token:'refresh',expires_at:9999999999,user:{id:'00000000-0000-4000-8000-000000000001'}};
 else if(path.endsWith('/es_me'))d={id:'00000000-0000-4000-8000-000000000001',nickname:'Jogador Teste',xp:450,ranking_points:35,online_wins:5,online_losses:2,private_wins:3,private_losses:1,impostor_wins:2,impostor_losses:1,common_wins:6,common_losses:2,avatar_url:null};
 else if(path.endsWith('/es_my_titles'))d=[{code:'detetive_iniciante',name:'Aprendiz de Detetive',rarity:'comum',description:'Cinco vitórias como comum',equipped:false}];
 else if(path.endsWith('/es_equip_title'))d=null;
 else if(path.endsWith('/es_leaderboard'))d=[{nickname:'Jogador Teste',xp:450,online_wins:5,ranking_points:35,avatar_url:null,equipped_title:'detetive_iniciante'}];
 else if(path.endsWith('/es_title_catalog'))d=[{code:'detetive_iniciante',name:'Aprendiz de Detetive',rarity:'comum'}];
 return {ok:true,status:200,text:async()=>JSON.stringify(d)};
 };""")
 for n in ['server-config.js','words.js','engine.js','audio.js','online.js','app.js']:
  page.add_script_tag(content=(base/n).read_text())
 page.locator('#skip').click();page.locator('#online').click()
 page.locator('#cloudUrl').fill('https://exemplo.supabase.co')
 page.locator('#cloudKey').fill('sb_publishable_abcdefghijklmnopqrstuv')
 page.locator('#cloudSave').click()
 page.locator('#emailOn').fill('jogador@example.com')
 page.locator('#passwordOn').fill('123456')
 page.locator('#loginOn').click()
 page.locator('#profileOn').click()
 assert page.get_by_text('Aprendiz de Detetive').is_visible()
 assert page.locator('#uploadPhoto').is_visible()
 page.locator('[data-equip="0"]').click()
 assert page.get_by_text('Aprendiz de Detetive').is_visible()
 page.locator('#onlineBack').click()
 page.locator('#rankingOn').click()
 assert page.get_by_text('Jogador Teste').is_visible()
 assert not errors,errors
 print('PROFILE UI mock PASS')
 browser.close()
