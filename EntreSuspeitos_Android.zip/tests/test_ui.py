from playwright.sync_api import sync_playwright
from pathlib import Path
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1,has_touch=True,is_mobile=True)
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 base=str(Path(__file__).resolve().parents[1]/'www')+'/'
 html=Path(base+'index.html').read_text(encoding='utf8')
 import re
 html=re.sub(r'<script src=\"[^\"]+\"></script>','',html)
 html=html.replace('<link rel=\"stylesheet\" href=\"style.css\">','')
 page.set_content(html)
 page.add_style_tag(content=Path(base+'style.css').read_text(encoding='utf8'))
 for n in ['server-config.js','words.js','engine.js','audio.js','online.js','app.js']:
  page.add_script_tag(content=Path(base+n).read_text(encoding='utf8'))
 page.locator('#skip').click()
 assert page.locator('#offline').is_visible()
 page.screenshot(path=str(Path(__file__).parent/'menu_v4.png'),full_page=True)
 page.locator('#settings').click()
 assert page.get_by_text('Música ambiente de suspense').count()==1
 page.locator('#back').click()
 page.locator('#offline').click()
 assert page.locator('#start').is_visible()
 page.locator('#start').click()
 assert page.locator('#card').is_visible()
 assert not page.get_by_text('Esconder e passar para o próximo').count()
 for i in range(4):
  assert page.locator('#card').is_visible()
  page.locator('#card').dispatch_event('pointerdown',{'pointerId':1})
  assert page.locator('#card').get_attribute('class').find('revealed')>=0
  page.locator('#card').dispatch_event('pointerup',{'pointerId':1})
  assert 'revealed' not in page.locator('#card').get_attribute('class')
  page.locator('#next').click()
 assert page.locator('#finish').is_visible()
 page.on('dialog',lambda d:d.accept())
 page.locator('#finish').click()
 assert page.get_by_text('Segredos revelados').is_visible()
 page.screenshot(path=str(Path(__file__).parent/'result_v4.png'),full_page=True)
 page.locator('#home').click()
 page.locator('#online').click()
 assert page.get_by_role('heading',name='Conectar servidor').is_visible()
 print('UI PASS',errors)
 assert not errors
 browser.close()
