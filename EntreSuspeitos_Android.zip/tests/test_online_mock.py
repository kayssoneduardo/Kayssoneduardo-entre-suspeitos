from playwright.sync_api import sync_playwright
from pathlib import Path
import re
base=Path(__file__).resolve().parents[1]/'www'
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 html=re.sub(r'<script src="[^"]+"></script>','', (base/'index.html').read_text())
 page.set_content(html)
 page.add_style_tag(content=(base/'style.css').read_text())
 page.add_init_script("window.ES_FAKE=true")
 page.evaluate("""window.fetch=async (url,opt)=>{let path=String(url);let answer=null;
 if(path.includes('/auth/v1/token'))answer={access_token:'testjwt',refresh_token:'refresh',expires_at:9999999999,user:{id:'00000000-0000-4000-8000-000000000001'}};
 else if(path.includes('/rest/v1/rpc/es_create'))answer='bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
 else if(path.includes('/rest/v1/rpc/es_room_view'))answer={id:'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb',code:'CAFE01',owner:'00000000-0000-4000-8000-000000000001',public:true,status:'lobby',max:10,impostors:2,categories:['Animais'],difficulty:'Misturado',clue:'both',know:false,round:0,players:[{id:'00000000-0000-4000-8000-000000000001',nick:'Teste',ready:false,active:true,online:true}],me:{},results:[]};
 else if(path.includes('/rest/v1/rpc/'))answer=null;
 return {ok:true,status:200,text:async()=>JSON.stringify(answer)};};""")
 for n in ['server-config.js','words.js','engine.js','audio.js','online.js','app.js']:
  page.add_script_tag(content=(base/n).read_text())
 page.locator('#skip').click()
 page.locator('#online').click()
 assert page.get_by_role('heading',name='Conectar servidor').is_visible()
 page.locator('#cloudUrl').fill('https://exemplo.supabase.co')
 page.locator('#cloudKey').fill('sb_publishable_abcdefghijklmnopqrstuv')
 page.locator('#cloudSave').click()
 assert page.locator('#loginOn').is_visible()
 page.locator('#emailOn').fill('teste@example.com')
 page.locator('#passwordOn').fill('minhasenha')
 page.locator('#loginOn').click()
 assert page.locator('#create').is_visible()
 page.locator('#create').click()
 assert page.locator('#makeRoom').is_visible()
 page.locator('#makeRoom').click()
 assert page.locator('#readyOn').is_visible()
 assert page.locator('#voiceOn').is_visible()
 print('ONLINE UI mock PASS',errors)
 assert errors==[]
 browser.close()
