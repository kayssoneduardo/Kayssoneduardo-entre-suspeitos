'use strict';
const assert=require('assert');
const fs=require('fs');
const vm=require('vm');
const ES=require('../www/engine.js');
const context={window:{}};vm.createContext(context);
vm.runInContext(fs.readFileSync(require('path').join(__dirname,'../www/words.js'),'utf8'),context);
const bank=context.window.ES_WORD_BANK;
const {report,total}=ES.validateBank(bank);
assert.strictEqual(Object.keys(report).length,12);
assert(total>=1200);
for(const [category,count] of Object.entries(report))assert(count>=100,`${category}: ${count}`);
assert.strictEqual(ES.maxImpostors(4),1);
assert.strictEqual(ES.maxImpostors(6),2);
assert.strictEqual(ES.maxImpostors(10),4);
const list=['Animais'];const used=new Set();
const size=bank.Animais.filter(x=>x.d==='Fácil').length;
const words=new Set();
for(let i=0;i<size;i++){
 const word=ES.selectWord(bank,list,'Fácil',used,max=>i%max);
 assert(!words.has(word.w));words.add(word.w);
}
assert.strictEqual(words.size,size);
const more=ES.selectWord(bank,list,'Fácil',used,()=>0);
assert.strictEqual(more.reset,true);
assert(used.size===1);
const weights={};
for(let roll=0;roll<100;roll++){
 let called=0;
 const p=ES.selectOpening(max=>{if(called++===0)return roll;return 0;});
 weights[p.tier]=(weights[p.tier]||0)+1;
}
assert.deepStrictEqual(weights,{special:1,rare:9,uncommon:20,common:70});
console.log('PASS: 12 categorias, '+total+' palavras, 100+ cada, dicas e três níveis.');
console.log('PASS: limites de impostores, não repetição e chances de abertura 70/20/9/1.');
