import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';

void main() {
 test('Banco legado contém doze categorias e 1322 palavras', () {
  final words=jsonDecode(File('assets/words.json').readAsStringSync()) as Map<String,dynamic>;
  expect(words.length,12);
  expect(words.values.fold<int>(0,(sum,category)=>sum+(category as List).length),1322);
  for(final items in words.values){expect((items as List).length,greaterThanOrEqualTo(100));}
 });
}
