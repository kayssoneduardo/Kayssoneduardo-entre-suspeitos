# Entre Suspeitos — V5 Flutter/Dart (primeira base migrada)

Projeto Flutter novo baseado na V4 (WebView/JavaScript), com **12 categorias e 1.322 palavras reais recuperadas**, modo offline nativo, cadastro por e-mail Supabase, menu online, salas com voto e resultados, voz WebRTC experimental (STUN), trilha original de suspense e verificação de papel administrativo via `es_is_admin()`.

## Atenção — estado real

- Código-fonte entregue; **Flutter SDK não estava instalado no ambiente de edição, portanto ainda não houve compilação Android, teste estático Dart nem teste em aparelhos reais**. Use o workflow GitHub Actions incluído para obter o primeiro relatório de compilação.
- A voz WebRTC é **experimental**, exigirá testes de rede real e provável servidor TURN para NAT móvel. A solicitação de permissão ocorre ao tocar em `ATIVAR MICROFONE NA SALA`. A música para quando a sala abre.
- A integração do backend reutiliza os RPCs da **V4 instalada**; aplique `backend/02_v5_seguranca.sql` antes de testar cadastro. A migração exige a conta do proprietário com e-mail confirmado.
- Não implementei ainda foto de perfil, denúncias completas, kick/mute administrativo no servidor, convite por deep link registrado no Android/iOS, login Facebook, loja, push notifications, nem sistema de títulos na interface. Não declare esses recursos prontos.
- Compartilhar o código da sala via WhatsApp funciona; o deep link incluído é informativo e ainda não é associado ao sistema operacional.
- Ranking e estatísticas dependem de palavras carregadas no banco. O pacote V4 contém um RPC `es_admin_seed` para publicação da lista, mas o seed de 1322 entradas não é executado automaticamente neste pacote.

## Android (somente celular / GitHub)

1. Envie o ZIP **`EntreSuspeitos_Flutter_V5.zip`** na raiz do mesmo repositório GitHub, preservando o projeto V4.
2. Crie `.github/workflows/gerar-apk-flutter-v5.yml` copiando o arquivo distribuído junto com este pacote. Não substitua o workflow antigo ainda.
3. Mantenha GitHub Actions Variables `SUPABASE_URL` e `SUPABASE_ANON_KEY` (chave publishable ou anon pública) já configuradas. **Nunca coloque senha do banco ou `service_role` no APK**.
4. Execute o workflow `Gerar APK Flutter V5` e baixe o artifact `Entre-Suspeitos-Flutter-V5-APK`.
5. Instale como um novo aplicativo; o identificador base do Flutter pode ser diferente da V4. Não exclua a versão V4 antes de validar a nova.

## Banco

Aplique `backend/02_v5_seguranca.sql` ao projeto Supabase V4 com uma execução PostgreSQL autenticada (GitHub Actions existente). Ele reserva o apelido `Zero`, verifica privilégios usando UUID da conta confirmada, remove outros administradores pré-existentes, corrige apelidos antigos duplicados, adiciona unicidade insensível a maiúsculas e espaços e cria RPC público de disponibilidade de apelido. Faça backup antes: a migração altera os apelidos duplicados antigos e a tabela de administradores.

**Segurança**: o painel não aparece em perfis comuns; a RPC administrativa também verifica `es_is_admin` no servidor. A renderização do botão por si só não é autorização. O usuário proprietário é localizado uma única vez pela conta de e-mail confirmada e fica vinculado ao UUID.

## iOS

Este projeto é compatível em princípio com iOS via Flutter. Para gerar um IPA e publicar, ainda são necessários um runner macOS, perfil de assinatura Apple, CocoaPods, configurações `NSMicrophoneUsageDescription` e os testes específicos de iOS. Não há IPA neste pacote.
