# Verificações antes de publicar

- [ ] `flutter pub get` executa corretamente no GitHub.
- [ ] `flutter test` verifica o banco de palavras.
- [ ] APK é gerado e inicia no Android.
- [ ] Supabase Auth: registro, confirmação por e-mail, login, logout, recuperação.
- [ ] Apelidos duplicados (ZERO, Zero, Z e r o) são bloqueados no servidor.
- [ ] Somente UUID do proprietário possui `es_is_admin() = true`.
- [ ] Usuário comum não acessa RPC `es_admin_dashboard()` nem o painel.
- [ ] 4 aparelhos na sala, solicita permissão para microfone; todos ouvem voz.
- [ ] Redes móveis com NAT: testar necessidade de TURN.
- [ ] Música no menu; para ao entrar no lobby; retorna ao sair.
- [ ] Criar sala, entrar por código, pronto, iniciar partida com 4, votar e receber resultado.
- [ ] Reconexão após queda de internet sem duplicar jogador.
- [ ] Offline com 4 e 30 jogadores; não há repetição de palavras até esgotar seleção.
- [ ] Fotos, moderação completa, convites deep link e títulos: ainda pendentes.
