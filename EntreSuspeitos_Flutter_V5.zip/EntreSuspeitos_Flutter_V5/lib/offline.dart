import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OfflinePage extends StatefulWidget {const OfflinePage({super.key}); @override State<OfflinePage> createState()=>_OfflinePageState();}
class _OfflinePageState extends State<OfflinePage> {
 final names=TextEditingController();
 Map<String,dynamic> bank={};
 final selected=<String>{};
 String difficulty='Misturado', clue='both';
 int impostors=1, index=0;
 List<String> players=[];
 Set<int> impostorIndices={};
 Map<String,dynamic>? word;
 String category='';
 bool playing=false, revealing=false, knowEachOther=false;
 late SharedPreferences prefs;
 @override void initState(){super.initState();_load();}
 Future<void> _load() async {
   prefs=await SharedPreferences.getInstance();
   bank=jsonDecode(await rootBundle.loadString('assets/words.json')) as Map<String,dynamic>;
   names.text=prefs.getString('offlineNames')??'';
   selected.addAll((prefs.getStringList('offlineCategories')??bank.keys.toList()).where(bank.containsKey));
   if(mounted)setState((){});
 }
 @override void dispose(){names.dispose();super.dispose();}
 void start(){
   final ps=names.text.split(RegExp('[,;\\n]')).map((s)=>s.trim()).where((s)=>s.isNotEmpty).toList();
   if(ps.length<4||ps.length>30){_msg('Informe de 4 a 30 jogadores, separados por vírgula ou linha.');return;}
   if(ps.map((x)=>x.toLowerCase()).toSet().length!=ps.length){_msg('Não repita nomes de jogadores.');return;}
   if(impostors>(ps.length-1)~/2){_msg('Escolha menos impostores que jogadores comuns.');return;}
   if(selected.isEmpty){_msg('Escolha ao menos uma categoria.');return;}
   final pool=<Map<String,dynamic>>[];
   for(final c in selected){for(final w in (bank[c] as List)){final x=Map<String,dynamic>.from(w as Map);if(difficulty=='Misturado'||x['d']==difficulty){x['c']=c;pool.add(x);}}}
   if(pool.isEmpty){_msg('Não há palavras disponíveis.');return;}
   final history=prefs.getStringList('usedWords')?.toSet()??<String>{};
   var remaining=pool.where((w)=>!history.contains('${w['c']}|${w['w']}')).toList();
   if(remaining.isEmpty){for(final w in pool){history.remove('${w['c']}|${w['w']}');}remaining=pool;}
   final rng=Random.secure();final chosen=remaining[rng.nextInt(remaining.length)];
   history.add('${chosen['c']}|${chosen['w']}');prefs.setStringList('usedWords',history.toList());
   prefs.setString('offlineNames',names.text);prefs.setStringList('offlineCategories',selected.toList());
   final indices=List<int>.generate(ps.length,(i)=>i)..shuffle(rng);
   setState((){players=ps;impostorIndices=indices.take(impostors).toSet();word=chosen;category=chosen['c'].toString();index=0;playing=true;revealing=false;});
 }
 void _msg(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(playing?'Distribuição secreta':'Jogar offline')),body:SafeArea(child:playing?_round():_setup()));
 Widget _setup()=>ListView(padding:const EdgeInsets.all(18),children:[
   const Text('Um único celular, passando entre os jogadores.'),const SizedBox(height:16),
   TextField(controller:names,maxLines:5,decoration:const InputDecoration(labelText:'Jogadores',hintText:'Ana, João, Maria, Pedro')),
   const SizedBox(height:14),Text('Impostores: $impostors'),Slider(value:impostors.clamp(1,14).toDouble(),min:1,max:14,divisions:13,label:'$impostors',onChanged:(v)=>setState(()=>impostors=v.round())),
   DropdownButtonFormField<String>(initialValue:difficulty,decoration:const InputDecoration(labelText:'Dificuldade'),items:['Misturado','Fácil','Médio','Difícil'].map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(),onChanged:(v)=>setState(()=>difficulty=v!)),
   const SizedBox(height:14),DropdownButtonFormField<String>(initialValue:clue,decoration:const InputDecoration(labelText:'Pista do impostor'),items:const [DropdownMenuItem(value:'both',child:Text('Categoria e dica')),DropdownMenuItem(value:'category',child:Text('Somente categoria')),DropdownMenuItem(value:'hint',child:Text('Somente dica')),DropdownMenuItem(value:'none',child:Text('Nenhuma'))],onChanged:(v)=>setState(()=>clue=v!)),
   SwitchListTile(title:const Text('Impostores se conhecem'),value:knowEachOther,onChanged:(v)=>setState(()=>knowEachOther=v)),
   const Text('Categorias'),Wrap(spacing:6,children:bank.keys.map((c)=>FilterChip(label:Text(c),selected:selected.contains(c),onSelected:(v)=>setState((){if(v){selected.add(c);}else{selected.remove(c);}}))).toList()),
   const SizedBox(height:20),FilledButton(onPressed:start,child:const Text('DISTRIBUIR PAPÉIS')),
 ]);
 Widget _round(){
  if(index>=players.length)return Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Icon(Icons.visibility_off,size:72),const Text('Todos viram seus papéis.'),const SizedBox(height:18),FilledButton(onPressed:()=>setState(()=>playing=false),child:const Text('NOVA RODADA COM MESMO GRUPO'))]));
  final imp=impostorIndices.contains(index);
  final partners=impostorIndices.where((x)=>x!=index).map((x)=>players[x]).join(', ');
  return Padding(padding:const EdgeInsets.all(22),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
   Text('Jogador ${index+1}/${players.length}',style:Theme.of(context).textTheme.titleMedium),
   const SizedBox(height:12),Text(players[index],style:Theme.of(context).textTheme.headlineMedium),
   const SizedBox(height:25),
   GestureDetector(onLongPressStart:(_)=>setState(()=>revealing=true),onLongPressEnd:(_)=>setState(()=>revealing=false),child:Container(width:double.infinity,height:210,alignment:Alignment.center,decoration:BoxDecoration(color:const Color(0xff241925),borderRadius:BorderRadius.circular(20),border:Border.all(color:Colors.redAccent)),child:revealing?
    Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(imp?'IMPOSTOR':'JOGADOR COMUM',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:24)),const SizedBox(height:12),if(!imp)Text('PALAVRA: ${word!['w']}',style:const TextStyle(fontSize:21)),if(imp&&['both','category'].contains(clue))Text('Categoria: $category'),if(imp&&['both','hint'].contains(clue))Text('Dica: ${word!['h']}'),if(imp&&knowEachOther&&partners.isNotEmpty)Text('Parceiros: $partners')]):const Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(Icons.lock,size:48),Text('SEGURE PARA REVELAR')]))),
   const SizedBox(height:18),const Text('Solte o dedo para esconder seu papel.'),const SizedBox(height:25),
   FilledButton(onPressed:revealing?null:()=>setState(()=>index++),child:const Text('PRÓXIMO JOGADOR')),
  ]));
 }
}
