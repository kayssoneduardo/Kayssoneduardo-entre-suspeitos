import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'main.dart';
import 'voice.dart';

class OnlinePage extends StatefulWidget {
 final ValueChanged<bool> onRoom;
 const OnlinePage({super.key,required this.onRoom});
 @override State<OnlinePage> createState()=>_OnlinePageState();
}
class _OnlinePageState extends State<OnlinePage> {
 late final StreamSubscription<AuthState> authSub;
 bool waiting=false;
 @override void initState(){super.initState();authSub=db.auth.onAuthStateChange.listen((_){if(mounted)setState((){});});}
 @override void dispose(){authSub.cancel();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Jogar online')),body:SafeArea(child:db.auth.currentUser==null?AuthPanel(onBusy:(x)=>setState(()=>waiting=x)):OnlineHub(onRoom:widget.onRoom)));
}
class AuthPanel extends StatefulWidget {
 final ValueChanged<bool> onBusy;
 const AuthPanel({super.key,required this.onBusy});
 @override State<AuthPanel> createState()=>_AuthPanelState();
}
class _AuthPanelState extends State<AuthPanel>{
 final email=TextEditingController(),pass=TextEditingController(),nick=TextEditingController();
 bool signup=false,busy=false,submitted=false;
 @override void dispose(){email.dispose();pass.dispose();nick.dispose();super.dispose();}
 Future<void> doAuth() async {
  if(busy)return;
  if(email.text.trim().isEmpty||pass.text.length<6){message(context,'Informe e-mail e senha de pelo menos 6 caracteres.');return;}
  setState(()=>busy=true);
  try{
   if(signup){
    final nickname=nick.text.trim();
    if(nickname.length<2||nickname.length>28){throw Exception('Apelido deve ter entre 2 e 28 caracteres.');}
    if(nickname.replaceAll(RegExp(r'\s+'),'').toLowerCase()=='zero'){throw Exception('Este apelido está reservado.');}
    final available=await db.rpc('es_nickname_available',params:{'p_nick':nickname});
    if(available!=true)throw Exception('Esse apelido já está em uso.');
    final response=await db.auth.signUp(email:email.text.trim(),password:pass.text,data:{'nickname':nickname});
    if(response.session==null){
      final savedEmail=email.text.trim();
      pass.clear();nick.clear();setState((){signup=false;submitted=true;});
      message(context,'Cadastro recebido! Confirme o e-mail de $savedEmail e depois entre.');
    }else{pass.clear();nick.clear();setState(()=>signup=false);}
   }else{
    await db.auth.signInWithPassword(email:email.text.trim(),password:pass.text);
    pass.clear();
   }
  }catch(e){message(context,readableError(e));}
  finally{if(mounted)setState(()=>busy=false);}
 }
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[
  const Icon(Icons.person_pin,size:65),const SizedBox(height:20),
  Text(signup?'Crie sua conta':'Entre na sua conta',style:Theme.of(context).textTheme.headlineSmall,textAlign:TextAlign.center),
  if(submitted&&!signup)const Card(child:Padding(padding:EdgeInsets.all(15),child:Text('Cadastro enviado. Abra seu e-mail e confirme sua conta antes de entrar.'))),
  const SizedBox(height:20),TextField(controller:email,keyboardType:TextInputType.emailAddress,autofillHints:const [AutofillHints.email],decoration:const InputDecoration(labelText:'E-mail')),
  const SizedBox(height:12),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Senha')),
  if(signup)...[const SizedBox(height:12),TextField(controller:nick,maxLength:28,decoration:const InputDecoration(labelText:'Apelido único'))],
  const SizedBox(height:18),FilledButton(onPressed:busy?null:doAuth,child:busy?const SizedBox(height:22,width:22,child:CircularProgressIndicator(strokeWidth:2)):Text(signup?'CRIAR CONTA':'ENTRAR')),
  TextButton(onPressed:busy?null:()=>setState((){signup=!signup;submitted=false;pass.clear();}),child:Text(signup?'Já tenho conta':'Criar conta')),
  TextButton(onPressed:busy?null:() async {if(email.text.trim().isEmpty){message(context,'Informe o e-mail para recuperar a senha.');return;}try{await db.auth.resetPasswordForEmail(email.text.trim());if(context.mounted)message(context,'Se o e-mail estiver cadastrado, receberá as instruções.');}catch(e){if(context.mounted)message(context,readableError(e));}},child:const Text('Esqueci minha senha')),
 ]);
}

class OnlineHub extends StatefulWidget {
 final ValueChanged<bool> onRoom;
 const OnlineHub({super.key,required this.onRoom});
 @override State<OnlineHub> createState()=>_OnlineHubState();
}
class _OnlineHubState extends State<OnlineHub> {
 Map<String,dynamic> profile={}; bool isAdmin=false,loading=true;
 @override void initState(){super.initState();load();}
 Future<void> load() async {
  try{
   final p=await db.rpc('es_me'); final a=await db.rpc('es_is_admin');
   if(!mounted)return;
   setState((){profile=Map<String,dynamic>.from(p as Map? ?? {});isAdmin=a==true;loading=false;});
  }catch(e){if(mounted){setState(()=>loading=false);message(context,readableError(e));}}
 }
 Future<void> create() async {
  try{
   final id=await db.rpc('es_create',params:{'p_public':false,'p_max':10,'p_impostors':1,'p_categories':['Animais','Comidas','Objetos'],'p_difficulty':'Misturado','p_clue':'both','p_know':false});
   if(mounted)openRoom(id.toString());
  }catch(e){if(mounted)message(context,readableError(e));}
 }
 Future<void> joinCode() async {
  final c=TextEditingController();
  final code=await showDialog<String>(context:context,builder:(context)=>AlertDialog(title:const Text('Entrar em sala'),content:TextField(controller:c,textCapitalization:TextCapitalization.characters,decoration:const InputDecoration(labelText:'Código da sala')),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(context,c.text.trim()),child:const Text('Entrar'))]));
  c.dispose();
  if(code==null||code.isEmpty)return;
  try{final id=await db.rpc('es_join_code',params:{'p_code':code});if(mounted)openRoom(id.toString());}catch(e){if(mounted)message(context,readableError(e));}
 }
 Future<void> rooms() async {
  try{
   final rs=await db.rpc('es_public_rooms');
   if(!mounted)return;
   await showModalBottomSheet<void>(context:context,isScrollControlled:true,builder:(c)=>SafeArea(child:ListView(shrinkWrap:true,children:[const ListTile(title:Text('Salas públicas')),for(final raw in (rs as List? ?? [])) ListTile(title:Text('${(raw as Map)['players']}/${raw['max_players']} jogadores'),subtitle:Text('Dificuldade: ${raw['difficulty']}'),trailing:const Icon(Icons.login),onTap:() async {try{final id=await db.rpc('es_join',params:{'p_room':raw['id']});if(c.mounted)Navigator.pop(c);if(mounted)openRoom(id.toString());}catch(e){if(mounted)message(context,readableError(e));}}),if((rs as List).isEmpty)const ListTile(title:Text('Nenhuma sala disponível'))])));
  }catch(e){if(mounted)message(context,readableError(e));}
 }
 Future<void> openRoom(String id) async {
  widget.onRoom(true);
  await Navigator.push(context,MaterialPageRoute(builder:(_)=>RoomPage(roomId:id)));
  widget.onRoom(false);
 }
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[
  if(loading)const LinearProgressIndicator(),
  Text('Olá, ${profile['nickname']??'jogador'}!',style:Theme.of(context).textTheme.headlineSmall),
  const SizedBox(height:8),Text('XP: ${profile['xp']??0} • Vitórias públicas: ${profile['online_wins']??0}'),
  const SizedBox(height:22),FilledButton.icon(onPressed:create,icon:const Icon(Icons.add),label:const Text('CRIAR SALA PRIVADA')),
  const SizedBox(height:10),FilledButton.tonalIcon(onPressed:rooms,icon:const Icon(Icons.public),label:const Text('SALAS PÚBLICAS')),
  const SizedBox(height:10),OutlinedButton.icon(onPressed:joinCode,icon:const Icon(Icons.key),label:const Text('ENTRAR COM CÓDIGO')),
  const SizedBox(height:15),ListTile(leading:const Icon(Icons.person),title:const Text('Meu perfil'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProfilePage(initial:profile,onSaved:load)))),
  ListTile(leading:const Icon(Icons.leaderboard),title:const Text('Ranking'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const LeaderboardPage()))),
  if(isAdmin)ListTile(leading:const Icon(Icons.admin_panel_settings),title:const Text('PAINEL ADMINISTRATIVO — ZERO'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AdminPage()))),
  TextButton(onPressed:()=>db.auth.signOut(),child:const Text('Sair da conta')),
 ]);
}

class ProfilePage extends StatefulWidget {
 final Map<String,dynamic> initial; final VoidCallback onSaved;
 const ProfilePage({super.key,required this.initial,required this.onSaved});
 @override State<ProfilePage> createState()=>_ProfilePageState();
}
class _ProfilePageState extends State<ProfilePage>{
 late final TextEditingController nick;
 @override void initState(){super.initState();nick=TextEditingController(text:widget.initial['nickname']?.toString()??'');}
 @override void dispose(){nick.dispose();super.dispose();}
 Future<void> save() async {try{await db.rpc('es_set_nickname',params:{'p_nick':nick.text.trim()});if(mounted){message(context,'Apelido atualizado!');widget.onSaved();Navigator.pop(context);}}catch(e){if(mounted)message(context,readableError(e));}}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Meu perfil')),body:ListView(padding:const EdgeInsets.all(20),children:[TextField(controller:nick,maxLength:28,decoration:const InputDecoration(labelText:'Apelido exclusivo')),FilledButton(onPressed:save,child:const Text('Salvar apelido')),const SizedBox(height:25),for(final k in ['xp','ranking_points','online_wins','online_losses','private_wins','private_losses','impostor_wins','common_wins'])ListTile(title:Text(k.replaceAll('_',' ').toUpperCase()),trailing:Text('${widget.initial[k]??0}'))]));
}
class LeaderboardPage extends StatefulWidget{const LeaderboardPage({super.key});@override State<LeaderboardPage> createState()=>_LeaderboardPageState();}
class _LeaderboardPageState extends State<LeaderboardPage>{ List data=[];@override void initState(){super.initState();db.rpc('es_leaderboard').then((v){if(mounted)setState(()=>data=v as List? ??[]);}).catchError((Object e){if(mounted)message(context,readableError(e));});}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Ranking público')),body:ListView(children:[for(final p in data)ListTile(leading:const Icon(Icons.emoji_events),title:Text('${p['nickname']}'),subtitle:Text('${p['online_wins']} vitórias'),trailing:Text('${p['ranking_points']} pts'))]));}

class AdminPage extends StatefulWidget{const AdminPage({super.key});@override State<AdminPage> createState()=>_AdminPageState();}
class _AdminPageState extends State<AdminPage>{ Map<String,dynamic>? info;bool denied=false;
 @override void initState(){super.initState();load();}
 Future<void> load()async{try{if(await db.rpc('es_is_admin')!=true)throw Exception('Acesso negado');final res=await db.rpc('es_admin_dashboard');if(mounted)setState(()=>info=Map<String,dynamic>.from(res as Map));}catch(_){if(mounted)setState(()=>denied=true);}}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Administração')),body:denied?const Center(child:Text('Acesso restrito ao proprietário Zero')):info==null?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(18),children:[const Text('Painel protegido por autorização do Supabase'),for(final e in info!.entries)Card(child:ListTile(title:Text(e.key),subtitle:Text(e.value.toString(),maxLines:5,overflow:TextOverflow.ellipsis)))]));}

class RoomPage extends StatefulWidget{
 final String roomId;
 const RoomPage({super.key,required this.roomId});
 @override State<RoomPage> createState()=>_RoomPageState();
}
class _RoomPageState extends State<RoomPage> with WidgetsBindingObserver {
 Map<String,dynamic> room={};
 Timer? ticker;
 RoomVoice? voice;
 bool fetching=false,startingVoice=false,muted=false,autoVoiceRequested=false;
 String voiceError='';
 final selected=<String>{};
 @override void initState(){super.initState();WidgetsBinding.instance.addObserver(this);_refresh();ticker=Timer.periodic(const Duration(seconds:3),(_)=>_refresh());}
 @override void didChangeAppLifecycleState(AppLifecycleState state){if(state==AppLifecycleState.resumed)_refresh();}
 @override void dispose(){WidgetsBinding.instance.removeObserver(this);ticker?.cancel();voice?.close();super.dispose();}
 Future<void> _refresh()async{
  if(fetching)return;fetching=true;
  try{
   await db.rpc('es_touch',params:{'p_room':widget.roomId});
   final v=await db.rpc('es_room_view',params:{'p_room':widget.roomId});
   if(!mounted)return;
   final data=Map<String,dynamic>.from(v as Map);
   final players=(data['players'] as List? ??[]);
   if(voice?.active??false){await voice!.update(players.where((p)=>p['active']==true).map((p)=>p['id'].toString()).toList());}
   setState(()=>room=data);
   if(!autoVoiceRequested && players.isNotEmpty){
     autoVoiceRequested=true;
     WidgetsBinding.instance.addPostFrameCallback((_) {if(mounted)_voice();});
   }
   if(data['status']=='discussion' && _remaining()==0){await _call('es_begin_vote',quiet:true);}
   if(data['status']=='voting' && _remaining()==0){await _call('es_finalize',quiet:true);}
  }catch(e){if(mounted)message(context,readableError(e));}
  finally{fetching=false;}
 }
 int _remaining(){final end=DateTime.tryParse(room['phaseEnds']?.toString()??'');if(end==null)return 0;return end.difference(DateTime.now()).inSeconds.clamp(0,99999).toInt();}
 Future<void> _call(String name,{Map<String,dynamic>? args,bool quiet=false})async{
  try{await db.rpc(name,params:{'p_room':widget.roomId,...?args});if(!quiet)await _refresh();}
  catch(e){if(mounted&&!quiet)message(context,readableError(e));}
 }
 Future<void> _voice()async{
  if(voice?.active??false)return;
  setState(()=>startingVoice=true);
  try{
   final v=RoomVoice(db,widget.roomId,db.auth.currentUser!.id,(s){if(mounted)setState(()=>voiceError=s);});
   await v.start((room['players'] as List? ??[]).where((p)=>p['active']==true).map((p)=>p['id'].toString()).toList());
   voice=v;
   if(mounted)setState(()=>voiceError='');
  }catch(e){if(mounted)message(context,'Não foi possível iniciar o microfone: $e');}
  finally{if(mounted)setState(()=>startingVoice=false);}
 }
 Future<void> _leave()async {ticker?.cancel();await voice?.close();try{await db.rpc('es_leave',params:{'p_room':widget.roomId});}catch(_){ }if(mounted)Navigator.pop(context);}
 Future<void> _vote()async{
  try{await db.rpc('es_vote',params:{'p_room':widget.roomId,'p_targets':selected.toList()});if(mounted){message(context,'Voto registrado em segredo.');await _refresh();}}catch(e){if(mounted)message(context,readableError(e));}
 }
 @override Widget build(BuildContext context){
  final players=room['players'] as List? ??[];
  final me=db.auth.currentUser?.id;
  final mine=players.where((p)=>p['id']==me).toList();
  final isOwner=room['owner']==me;
  final state=room['status']?.toString()??'lobby';
  final myRole=Map<String,dynamic>.from(room['me'] as Map? ??{});
  final maxVote=(room['impostors'] as num?)?.toInt()??1;
  final remaining=_remaining();
  return PopScope(canPop:false,onPopInvokedWithResult:(didPop,result){if(!didPop)_leave();},child:Scaffold(appBar:AppBar(title:Text('Sala ${room['code']??'...'}'),actions:[IconButton(icon:const Icon(Icons.exit_to_app),onPressed:_leave)]),body:room.isEmpty?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(18),children:[
   Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[Text(state.toUpperCase(),style:Theme.of(context).textTheme.titleLarge),if(state=='discussion'||state=='voting')Text('Tempo restante: ${remaining~/60}:${(remaining%60).toString().padLeft(2,'0')}'),Text('${players.where((p)=>p['active']==true).length}/${room['max']} jogadores'),Text('Código: ${room['code']}'),TextButton.icon(icon:const Icon(Icons.share),label:const Text('Convidar por link'),onPressed:()=>Share.share('Vamos jogar Entre Suspeitos! Código: ${room['code']}\nentre-suspeitos://sala/${room['code']}\nSe o link não abrir, use o código dentro do jogo.'))]))),
   if(!(voice?.active??false))FilledButton.icon(icon:const Icon(Icons.mic),label:Text(startingVoice?'Conectando microfone...':'ATIVAR MICROFONE NA SALA'),onPressed:startingVoice?null:_voice)
   else SwitchListTile(secondary:Icon(muted?Icons.mic_off:Icons.mic),title:Text(muted?'Microfone desligado':'Microfone ligado'),value:!muted,onChanged:(v){voice?.mute(!v);setState(()=>muted=!v);}),
   if(voiceError.isNotEmpty)Text(voiceError,style:const TextStyle(color:Colors.amber)),
   const SizedBox(height:12),
   for(final p in players)Card(child:ListTile(leading:Icon(p['online']==true?Icons.circle:Icons.circle_outlined,color:p['online']==true?Colors.green:Colors.grey,size:15),title:Text('${p['nick']} ${p['id']==me?'(você)':''}'),trailing:state=='lobby'?Icon(p['ready']==true?Icons.check_circle:Icons.hourglass_empty,color:p['ready']==true?Colors.green:Colors.grey):null)),
   if(state=='lobby') ...[
    const SizedBox(height:12),SwitchListTile(title:const Text('Estou pronto'),value:mine.isNotEmpty&&mine.first['ready']==true,onChanged:(v)=>_call('es_ready',args:{'p_ready':v})),
    if(isOwner)FilledButton.icon(icon:const Icon(Icons.play_arrow),onPressed:players.where((p)=>p['active']==true).length>=4&&players.where((p)=>p['active']==true).every((p)=>p['ready']==true)?()=>_call('es_start'):null,label:const Text('INICIAR PARTIDA')),
    const Text('O anfitrião pode começar com 4 ou mais jogadores prontos.'),
   ],
   if(state=='discussion')...[
    const SizedBox(height:15),Card(color:myRole['impostor']==true?const Color(0xff501b27):const Color(0xff133d35),child:Padding(padding:const EdgeInsets.all(22),child:Column(children:[Text(myRole['impostor']==true?'VOCÊ É IMPOSTOR':'VOCÊ É JOGADOR COMUM',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),if(myRole['word']!=null)Text('Palavra: ${myRole['word']}',style:const TextStyle(fontSize:24)),if(myRole['category']!=null)Text('Categoria: ${myRole['category']}'),if(myRole['hint']!=null)Text('Dica: ${myRole['hint']}')]))),
    const Text('Converse com o grupo e tente descobrir quem está fingindo.'),
   ],
   if(state=='voting')...[
    Text('Escolha $maxVote suspeito(s), sem votar em si mesmo.',style:Theme.of(context).textTheme.titleMedium),
    for(final p in players.where((p)=>p['active']==true && p['id']!=me))CheckboxListTile(value:selected.contains(p['id']),title:Text('${p['nick']}'),onChanged:myRole['voted']==true?null:(v)=>setState((){if(v==true&&selected.length<maxVote){selected.add(p['id']);}else if(v==false){selected.remove(p['id']);}})),
    FilledButton(onPressed:myRole['voted']==true||selected.length!=maxVote?null:_vote,child:Text(myRole['voted']==true?'VOTO ENVIADO':'CONFIRMAR VOTO SECRETO')),
   ],
   if(state=='results')...[
    const Icon(Icons.shield,size:65,color:Colors.redAccent),
    Text('REVELAÇÃO',style:Theme.of(context).textTheme.headlineMedium,textAlign:TextAlign.center),
    Text('Palavra: ${myRole['word']??'?'}'),
    for(final raw in room['results'] as List? ??[] )ListTile(title:Text(players.where((p)=>p['id']==raw['user']).map((p)=>p['nick'].toString()).firstOrNull??'Jogador'),subtitle:Text(raw['impostor']==true?'Impostor':'Comum'),trailing:Text('${raw['win']==true?'Vitória':'Derrota'} · +${raw['xp']} XP')),
    if(isOwner)FilledButton(onPressed:()=>_call('es_next'),child:const Text('REVANCHE COM O MESMO GRUPO')),
   ],
   TextButton.icon(onPressed:_refresh,icon:const Icon(Icons.refresh),label:const Text('Atualizar sala')),
  ])));
 }
}
