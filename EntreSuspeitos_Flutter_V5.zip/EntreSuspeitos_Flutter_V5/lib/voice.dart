import 'dart:async';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Chat P2P experimental. Funciona no lobby e durante a partida.
/// Para redes móveis com NAT restritivo pode ser necessário servidor TURN.
class RoomVoice {
 final SupabaseClient client;
 final String roomId;
 final String me;
 final void Function(String) onError;
 final peers=<String,RTCPeerConnection>{};
 final renderers=<String,RTCVideoRenderer>{};
 final pending=<String,List<RTCIceCandidate>>{};
 MediaStream? local;
 Timer? poller;
 int lastSignal=0;
 bool active=false;
 bool muted=false;
 RoomVoice(this.client,this.roomId,this.me,this.onError);
 Future<void> start(List<String> ids) async {
  if(active)return;
  local=await navigator.mediaDevices.getUserMedia({'audio':{'echoCancellation':true,'noiseSuppression':true,'autoGainControl':true},'video':false});
  active=true;
  await update(ids);
  poller=Timer.periodic(const Duration(milliseconds:1300),(_)=>_poll());
 }
 Future<void> update(List<String> ids) async {
  if(!active)return;
  final others=ids.where((x)=>x!=me).toSet();
  for(final id in peers.keys.toList()) {if(!others.contains(id)){await peers.remove(id)?.close();await renderers.remove(id)?.dispose();}}
  for(final id in others){
   if(peers.containsKey(id))continue;
   final pc=await _peer(id);
   if(me.compareTo(id)<0){
    final offer=await pc.createOffer();await pc.setLocalDescription(offer);
    await _send(id,'offer',{'type':offer.type,'sdp':offer.sdp});
   }
  }
 }
 Future<RTCPeerConnection> _peer(String id) async {
  if(peers.containsKey(id))return peers[id]!;
  final pc=await createPeerConnection({'iceServers':[{'urls':'stun:stun.l.google.com:19302'},{'urls':'stun:stun1.l.google.com:19302'}]});
  peers[id]=pc;
  for(final track in local?.getAudioTracks()??<MediaStreamTrack>[]){pc.addTrack(track,local!);}
  pc.onIceCandidate=(candidate){if(candidate.candidate!=null){_send(id,'ice',{'candidate':candidate.candidate,'sdpMid':candidate.sdpMid,'sdpMLineIndex':candidate.sdpMLineIndex});}};
  pc.onTrack=(event) async {
   if(event.streams.isEmpty)return;
   final renderer=renderers[id]??RTCVideoRenderer();
   if(!renderers.containsKey(id)){await renderer.initialize();renderers[id]=renderer;}
   renderer.srcObject=event.streams.first;
  };
  return pc;
 }
 Future<void> _send(String to,String kind,Map<String,dynamic> payload) async {
  if(!active)return;
  await client.rpc('es_signal_send',params:{'p_room':roomId,'p_to':to,'p_kind':kind,'p_payload':payload});
 }
 Future<void> _poll() async {
  if(!active)return;
  try {
   final data=await client.rpc('es_signal_poll',params:{'p_room':roomId,'p_after':lastSignal});
   for(final raw in (data as List? ?? [])){
    final m=Map<String,dynamic>.from(raw as Map);
    final idx=(m['id'] as num).toInt();if(idx>lastSignal)lastSignal=idx;
    final from=m['from_id'].toString(), kind=m['kind'].toString();
    final payload=Map<String,dynamic>.from(m['payload'] as Map);
    final pc=await _peer(from);
    if(kind=='offer'){
     await pc.setRemoteDescription(RTCSessionDescription(payload['sdp'] as String?,payload['type'] as String?));
     final answer=await pc.createAnswer();await pc.setLocalDescription(answer);
     await _send(from,'answer',{'type':answer.type,'sdp':answer.sdp});
    } else if(kind=='answer'){
     await pc.setRemoteDescription(RTCSessionDescription(payload['sdp'] as String?,payload['type'] as String?));
    } else if(kind=='ice'){
     final ice=RTCIceCandidate(payload['candidate'] as String?,payload['sdpMid'] as String?,(payload['sdpMLineIndex'] as num?)?.toInt());
     if(await pc.getRemoteDescription()!=null){await pc.addCandidate(ice);}else{pending.putIfAbsent(from,()=>[]).add(ice);}
    }
    if(kind=='offer'||kind=='answer'){
     for(final ice in pending.remove(from)??[]){await pc.addCandidate(ice);}
    }
   }
  }catch(e){onError('Voz: $e');}
 }
 void mute(bool value){muted=value;for(final t in local?.getAudioTracks()??<MediaStreamTrack>[]){t.enabled=!value;}}
 Future<void> close() async {
  active=false;poller?.cancel();poller=null;
  for(final pc in peers.values){await pc.close();}peers.clear();
  for(final r in renderers.values){await r.dispose();}renderers.clear();
  for(final track in local?.getTracks()??<MediaStreamTrack>[]){await track.stop();}
  await local?.dispose();local=null;
 }
}
