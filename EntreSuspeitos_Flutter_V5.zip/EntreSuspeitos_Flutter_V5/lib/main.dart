import 'dart:async';
import 'dart:convert';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'offline.dart';
import 'online.dart';

const cloudUrl = String.fromEnvironment('SUPABASE_URL');
const cloudKey = String.fromEnvironment('SUPABASE_ANON_KEY');
late final SharedPreferences prefs;
SupabaseClient get db => Supabase.instance.client;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  prefs = await SharedPreferences.getInstance();
  if (cloudUrl.isNotEmpty && cloudKey.isNotEmpty) {
    await Supabase.initialize(url: cloudUrl, anonKey: cloudKey);
  }
  runApp(const EntreSuspeitos());
}

class EntreSuspeitos extends StatefulWidget {
  const EntreSuspeitos({super.key});
  @override
  State<EntreSuspeitos> createState() => _EntreSuspeitosState();
}

class _EntreSuspeitosState extends State<EntreSuspeitos> {
  final music = AudioPlayer();
  late bool musicEnabled;
  bool inRoom = false;
  @override
  void initState() {
    super.initState();
    musicEnabled = prefs.getBool('music') ?? true;
    _syncMusic();
  }
  Future<void> _syncMusic() async {
    if (!musicEnabled || inRoom) { await music.stop(); return; }
    try {
      await music.setReleaseMode(ReleaseMode.loop);
      await music.setVolume(.28);
      await music.play(AssetSource('suspense.wav'));
    } catch (_) { /* Música opcional; nunca bloquear uma partida. */ }
  }
  void setRoom(bool value) {
    if (inRoom == value) return;
    setState(() => inRoom = value);
    _syncMusic();
  }
  @override
  void dispose() { music.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final blue = prefs.getBool('blueTheme') ?? false;
    final accent = blue ? const Color(0xff7f65ed) : const Color(0xffc92e43);
    return MaterialApp(
      title: 'Entre Suspeitos', debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xff0b0c12),
        colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark),
        cardTheme: CardThemeData(color: const Color(0xff171922), margin: const EdgeInsets.symmetric(vertical: 8)),
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder(), contentPadding: EdgeInsets.symmetric(horizontal: 15, vertical: 12)),
        elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(48))),
      ),
      home: HomePage(onRoom: setRoom, musicEnabled: musicEnabled, onMusic: (v) {
        setState(() => musicEnabled = v); prefs.setBool('music', v); _syncMusic();
      }, onTheme: () {setState(() => prefs.setBool('blueTheme', !blue));}),
    );
  }
}

class HomePage extends StatefulWidget {
  final ValueChanged<bool> onRoom;
  final bool musicEnabled;
  final ValueChanged<bool> onMusic;
  final VoidCallback onTheme;
  const HomePage({super.key,required this.onRoom,required this.musicEnabled,required this.onMusic,required this.onTheme});
  @override
  State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  String phrase = 'Nem todos estão dizendo a verdade.';
  @override
  void initState() { super.initState();
    final roll = DateTime.now().microsecondsSinceEpoch % 100;
    if (roll == 0) phrase = 'O LULA está entre nós.';
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ENTRE SUSPEITOS'), centerTitle: true),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(22),children: [
      const SizedBox(height: 36),
      const Icon(Icons.shield_moon, size: 100),
      const SizedBox(height: 18),
      Text(phrase,textAlign: TextAlign.center,style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 48),
      FilledButton.icon(icon: const Icon(Icons.groups), label: const Text('JOGAR OFFLINE'),onPressed: () => Navigator.push(context,MaterialPageRoute(builder: (_) => const OfflinePage()))),
      const SizedBox(height: 12),
      FilledButton.tonalIcon(icon: const Icon(Icons.public), label: const Text('JOGAR ONLINE'), onPressed: () {
        if (cloudUrl.isEmpty || cloudKey.isEmpty) {message(context,'Supabase não configurado na compilação.');return;}
        Navigator.push(context,MaterialPageRoute(builder: (_) => OnlinePage(onRoom: widget.onRoom)));
      }),
      const SizedBox(height: 28),
      SwitchListTile(title: const Text('Música de suspense'), subtitle: const Text('Desliga automaticamente dentro de salas'),value: widget.musicEnabled,onChanged: widget.onMusic),
      ListTile(title: const Text('Alternar tema Sombra / Noturno'),leading: const Icon(Icons.palette),onTap:widget.onTheme),
      const SizedBox(height: 25),
      const Text('V5 Flutter • Versão inicial para testes',textAlign:TextAlign.center,style:TextStyle(color:Colors.white54)),
    ])),
  );
}
void message(BuildContext context, String msg) {
 if (!context.mounted) return;
 ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg),behavior:SnackBarBehavior.floating));
}
String readableError(Object e) {
 final s = e.toString();
 if (s.contains('Invalid login credentials')) return 'E-mail ou senha incorretos.';
 if (s.contains('Email not confirmed')) return 'Confirme o e-mail para entrar.';
 if (s.contains('duplicate key') || s.contains('apelido') || s.contains('nickname')) return 'Esse apelido já está em uso. Escolha outro.';
 return s.replaceFirst(RegExp(r'^Exception: '), '');
}
