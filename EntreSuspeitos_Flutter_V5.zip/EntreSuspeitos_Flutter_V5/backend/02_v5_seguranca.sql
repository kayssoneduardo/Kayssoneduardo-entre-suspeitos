-- ENTRE SUSPEITOS V5 — MIGRAÇÃO INCREMENTAL PARA O SUPABASE V4.
-- Execute UMA VEZ usando o fluxo GitHub Actions de banco, antes de testar o cadastro Flutter.
-- Não é necessário reinstalar as tabelas V4.
BEGIN;

-- Uma pessoa só pode administrar após autenticar sua conta real.
-- IMPORTANTE: deve existir auth.users com o e-mail confirmado indicado.
DO $$
DECLARE owner_id uuid;
BEGIN
 SELECT id INTO owner_id FROM auth.users
 WHERE lower(email)='kayssoneduardodias@gmail.com' AND email_confirmed_at IS NOT NULL
 ORDER BY created_at LIMIT 1;
 IF owner_id IS NULL THEN
   RAISE EXCEPTION 'A conta do proprietário precisa existir e ter e-mail confirmado antes da migração';
 END IF;
 -- Preserva a propriedade mesmo que o e-mail depois seja trocado; autorização usa UUID.
 DELETE FROM public.es_admins WHERE user_id<>owner_id;
 INSERT INTO public.es_admins(user_id) VALUES(owner_id) ON CONFLICT DO NOTHING;
 -- Libera o apelido reservado, se outra pessoa tiver cadastrado anteriormente.
 UPDATE public.es_profiles SET nickname='Jogador-'||substr(id::text,1,8)
 WHERE id<>owner_id AND lower(regexp_replace(btrim(nickname),'\s+','','g'))='zero';
 UPDATE public.es_profiles SET nickname='Zero' WHERE id=owner_id;
END$$;

-- Renomeia colisões legadas antes da criação do índice único.
WITH duplicates AS (
 SELECT id,row_number() OVER (
   PARTITION BY lower(regexp_replace(btrim(nickname),'\s+','','g'))
   ORDER BY CASE WHEN nickname='Zero' THEN 0 ELSE 1 END,id
 ) AS pos FROM public.es_profiles
)
UPDATE public.es_profiles p SET nickname='Jogador-'||substr(p.id::text,1,8)
FROM duplicates d WHERE d.id=p.id AND d.pos>1;

CREATE UNIQUE INDEX IF NOT EXISTS es_profiles_nickname_unique_v5
 ON public.es_profiles ((lower(regexp_replace(btrim(nickname),'\s+','','g'))));

CREATE OR REPLACE FUNCTION public.es_validate_nickname() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE owner_id uuid;
BEGIN
  NEW.nickname:=btrim(NEW.nickname);
  IF length(NEW.nickname) NOT BETWEEN 2 AND 28 THEN
    RAISE EXCEPTION 'Apelido deve ter de 2 a 28 caracteres';
  END IF;
  SELECT user_id INTO owner_id FROM public.es_admins LIMIT 1;
  IF lower(regexp_replace(NEW.nickname,'\s+','','g'))='zero' AND NEW.id IS DISTINCT FROM owner_id THEN
    RAISE EXCEPTION 'Apelido reservado ao proprietário';
  END IF;
  RETURN NEW;
END$$;
DROP TRIGGER IF EXISTS es_nickname_guard ON public.es_profiles;
CREATE TRIGGER es_nickname_guard BEFORE INSERT OR UPDATE OF nickname
 ON public.es_profiles FOR EACH ROW EXECUTE FUNCTION public.es_validate_nickname();

CREATE OR REPLACE FUNCTION public.es_nickname_available(p_nick text) RETURNS boolean
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public AS $$
DECLARE normalized text:=lower(regexp_replace(btrim(coalesce(p_nick,'')),'\s+','','g'));
BEGIN
 IF length(btrim(coalesce(p_nick,''))) NOT BETWEEN 2 AND 28 OR normalized='zero' THEN RETURN false;END IF;
 RETURN NOT EXISTS(SELECT 1 FROM public.es_profiles p
 WHERE lower(regexp_replace(btrim(p.nickname),'\s+','','g'))=normalized);
END$$;
REVOKE ALL ON FUNCTION public.es_nickname_available(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.es_nickname_available(text) TO anon,authenticated;

-- Evita que os nomes administrativos sejam lidos/escritos diretamente no REST.
REVOKE ALL ON TABLE public.es_admins FROM anon,authenticated;
ALTER TABLE public.es_admins ENABLE ROW LEVEL SECURITY;

-- A função do painel da V4 já consulta es_is_admin() no servidor.
-- Um cliente comum NÃO recebe acesso por esconder/mostrar botões.
COMMIT;
