from pathlib import Path
p=Path('android/app/src/main/AndroidManifest.xml')
s=p.read_text()
for perm in ['android.permission.INTERNET','android.permission.RECORD_AUDIO','android.permission.MODIFY_AUDIO_SETTINGS']:
 if perm not in s:
  s=s.replace('<application',f'<uses-permission android:name="{perm}" />\n    <application',1)
s=s.replace('android:label="entre_suspeitos"','android:label="Entre Suspeitos"')
p.write_text(s)
